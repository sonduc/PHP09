-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 05, 2011 at 01:17 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `xemay`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `config`
-- 

CREATE TABLE `config` (
  `config_id` int(11) NOT NULL auto_increment,
  `config_name` varchar(20) NOT NULL default '',
  `config_value` varchar(255) NOT NULL default '',
  `config_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`config_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `config`
-- 

INSERT INTO `config` VALUES (1, 'donvi', 'VNÐ', '0000-00-00 00:00:00');
INSERT INTO `config` VALUES (2, 'multilanguage', '0', '0000-00-00 00:00:00');
INSERT INTO `config` VALUES (3, 'visitors', '187480', '0000-00-00 00:00:00');
INSERT INTO `config` VALUES (4, 'maxpage', '10', '0000-00-00 00:00:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `customers`
-- 

CREATE TABLE `customers` (
  `customers_id` int(11) NOT NULL auto_increment,
  `customers_name` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL default '',
  `customers_sex` tinyint(3) default NULL,
  `customers_company` varchar(200) character set utf8 collate utf8_unicode_ci default NULL,
  `customers_address` varchar(200) character set utf8 collate utf8_unicode_ci default NULL,
  `customers_city` varchar(50) character set utf8 collate utf8_unicode_ci default NULL,
  `customers_state` varchar(50) character set utf8 collate utf8_unicode_ci default NULL,
  `customers_country` varchar(20) character set utf8 collate utf8_unicode_ci default NULL,
  `customers_phone` varchar(50) character set utf8 collate utf8_unicode_ci default NULL,
  `customers_email` varchar(50) character set utf8 collate utf8_unicode_ci default NULL,
  `customers_fax` varchar(50) character set utf8 collate utf8_unicode_ci default NULL,
  `customers_website` varchar(100) character set utf8 collate utf8_turkish_ci default NULL,
  `customers_username` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL default '',
  `customers_password` varchar(20) character set utf8 collate utf8_unicode_ci NOT NULL default '',
  `customers_recieve_newproduct` tinyint(1) default '0',
  `customers_recieve_newspecial` tinyint(1) default '0',
  `customers_date_added` datetime default NULL,
  `last_modified` int(11) default NULL,
  PRIMARY KEY  (`customers_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `customers`
-- 

INSERT INTO `customers` VALUES (3, 'Nguyễn Viết Tấn', 0, 'Tâm Bão', '21/13C Trường Sơn, Phường 4, Tân Bình', 'HCM', '', 'VN', '0909933533', 'nvtan@live.com', '', 'http://hostno1.vn', 'nvtan', '123456', 0, 0, '2010-08-27 15:33:09', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `doc_files`
-- 

CREATE TABLE `doc_files` (
  `doc_files_id` int(11) NOT NULL auto_increment,
  `doc_files_name` varchar(255) NOT NULL default '',
  `doc_files_description` varchar(255) default NULL,
  `doc_files_file` varchar(255) NOT NULL default '',
  `doc_files_type` varchar(25) default NULL,
  `doc_files_image` varchar(255) default NULL,
  `doc_files_status` tinyint(3) NOT NULL default '0',
  `doc_files_view` int(11) NOT NULL default '0',
  `doc_files_download` int(11) NOT NULL default '0',
  `doc_files_dateadded` datetime NOT NULL default '0000-00-00 00:00:00',
  `doc_files_categoriesid` int(11) default NULL,
  PRIMARY KEY  (`doc_files_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `doc_files`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `donvi`
-- 

CREATE TABLE `donvi` (
  `dv_id` int(11) NOT NULL auto_increment,
  `dv_name` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL default '',
  `dv_dateadded` datetime default NULL,
  `parent_id` varchar(11) NOT NULL default '0',
  PRIMARY KEY  (`dv_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `donvi`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `faq`
-- 

CREATE TABLE `faq` (
  `faq_id` int(11) NOT NULL auto_increment,
  `faq_question` text,
  `faq_answer` text,
  `faq_name` varchar(255) default NULL,
  `faq_phone` varchar(60) default NULL,
  `faq_email` varchar(100) default NULL,
  `faq_status` tinyint(1) default '0',
  `faq_sortorder` tinyint(3) default '0',
  `faq_dateadded` datetime default NULL,
  `faq_categoriesid` int(11) NOT NULL default '0',
  `faq_nameqa` text,
  `faq_gioitinh` int(3) default NULL,
  PRIMARY KEY  (`faq_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `faq`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `faq_categories`
-- 

CREATE TABLE `faq_categories` (
  `categories_id` int(11) NOT NULL auto_increment,
  `categories_name` varchar(60) NOT NULL default '',
  `categories_image` varchar(64) default NULL,
  `parent_id` int(11) NOT NULL default '0',
  `sort_order` int(3) NOT NULL default '0',
  `categories_status` tinyint(3) NOT NULL default '0',
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_modified` datetime default NULL,
  `categories_description` text,
  `language` varchar(4) default NULL,
  PRIMARY KEY  (`categories_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `faq_categories`
-- 

INSERT INTO `faq_categories` VALUES (1, 'Vietnam', NULL, 0, 0, 0, '0000-00-00 00:00:00', NULL, NULL, NULL);
INSERT INTO `faq_categories` VALUES (2, 'English', NULL, 0, 0, 0, '0000-00-00 00:00:00', NULL, NULL, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `languages`
-- 

CREATE TABLE `languages` (
  `languages_id` varchar(4) NOT NULL default '',
  `languages_name` varchar(50) default NULL,
  `languages_order` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`languages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `languages`
-- 

INSERT INTO `languages` VALUES ('en', 'English', 1);
INSERT INTO `languages` VALUES ('vn', 'Viet Nam', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `link_websites`
-- 

CREATE TABLE `link_websites` (
  `link_websites_id` int(11) NOT NULL auto_increment,
  `link_websites_name` varchar(255) NOT NULL default '',
  `link_websites_address` varchar(255) default NULL,
  `link_websites_language` int(11) default NULL,
  `link_websites_description` text,
  `link_websites_img` varchar(255) NOT NULL default '',
  `link_websites_imglarge` varchar(255) default NULL,
  `link_websites_status` tinyint(3) NOT NULL default '0',
  `link_websites_view` int(11) NOT NULL default '0',
  `link_websites_download` int(11) NOT NULL default '0',
  `link_websites_dateadded` datetime NOT NULL default '0000-00-00 00:00:00',
  `link_websites_categoriesid` int(11) default NULL,
  `link_websites_sortorder` tinyint(3) default '0',
  PRIMARY KEY  (`link_websites_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `link_websites`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `link_websites_categories`
-- 

CREATE TABLE `link_websites_categories` (
  `link_websites_categories_id` int(11) NOT NULL auto_increment,
  `link_websites_categories_parentid` int(11) NOT NULL default '0',
  `link_websites_categories_name` varchar(255) NOT NULL default '',
  `link_websites_categories_status` tinyint(3) NOT NULL default '0',
  `link_websites_categories_desc` text,
  `date_added` datetime default NULL,
  PRIMARY KEY  (`link_websites_categories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `link_websites_categories`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `news`
-- 

CREATE TABLE `news` (
  `news_id` int(11) NOT NULL auto_increment,
  `news_subject` text,
  `news_image` varchar(64) default NULL,
  `status` tinyint(3) default '0',
  `news_shortcontent` text,
  `news_content` longtext,
  `date_added` datetime default '0000-00-00 00:00:00',
  `last_modified` datetime default NULL,
  `categories_id` int(3) default NULL,
  `news_source` varchar(255) default NULL,
  `news_ordered` int(11) default '0',
  PRIMARY KEY  (`news_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `news`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `newscategories`
-- 

CREATE TABLE `newscategories` (
  `categories_id` int(11) NOT NULL auto_increment,
  `categories_name` varchar(60) NOT NULL default '',
  `status` tinyint(3) default '0',
  `parent_id` int(11) NOT NULL default '0',
  `sort_order` int(3) NOT NULL default '0',
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_modified` datetime default NULL,
  `categories_description` text,
  `language` varchar(8) default NULL,
  PRIMARY KEY  (`categories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `newscategories`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `news_hot`
-- 

CREATE TABLE `news_hot` (
  `ns_id` int(11) NOT NULL auto_increment,
  `news_id` int(11) NOT NULL default '0',
  `ns_sortorder` int(11) default '0',
  `ns_status` tinyint(3) default '0',
  `ns_dateadded` datetime default NULL,
  `categories_id` int(3) default NULL,
  `language` varchar(8) default NULL,
  PRIMARY KEY  (`ns_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=75 ;

-- 
-- Dumping data for table `news_hot`
-- 

INSERT INTO `news_hot` VALUES (66, 61, 0, 0, '2008-02-21 11:53:19', NULL, NULL);
INSERT INTO `news_hot` VALUES (67, 62, 0, 0, '2008-02-22 08:56:09', NULL, NULL);
INSERT INTO `news_hot` VALUES (68, 63, 0, 0, '2008-02-22 12:58:42', NULL, NULL);
INSERT INTO `news_hot` VALUES (69, 64, 0, 0, '2008-02-25 08:43:39', NULL, NULL);
INSERT INTO `news_hot` VALUES (70, 65, 0, 0, '2008-02-25 08:53:44', NULL, NULL);
INSERT INTO `news_hot` VALUES (72, 68, 0, 0, '2008-02-26 13:53:59', NULL, NULL);
INSERT INTO `news_hot` VALUES (73, 69, 0, 0, '2008-02-26 13:57:44', NULL, NULL);
INSERT INTO `news_hot` VALUES (74, 73, 0, 0, '2008-03-18 13:20:35', NULL, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `online`
-- 

CREATE TABLE `online` (
  `providers_id` int(11) NOT NULL auto_increment,
  `providers_name` varchar(255) default NULL,
  `providers_im` varchar(255) default NULL,
  `providers_phone` varchar(100) default NULL,
  `providers_email` varchar(255) default NULL,
  `providers_status` tinyint(3) default '0',
  `providers_dateadded` datetime NOT NULL default '0000-00-00 00:00:00',
  `language` varchar(4) default NULL,
  PRIMARY KEY  (`providers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `online`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `orderdetail`
-- 

CREATE TABLE `orderdetail` (
  `ordersdetail_id` int(11) NOT NULL auto_increment,
  `ordersdetail_product_id` int(11) default NULL,
  `ordersdetail_quantity` int(6) default '0',
  `ordersdetail_price` int(11) NOT NULL default '0',
  `ordersdetail_status` tinyint(3) NOT NULL default '0',
  `ordersdetail_ordersid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ordersdetail_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `orderdetail`
-- 

INSERT INTO `orderdetail` VALUES (1, 84, 1, 1528, 0, 0);
INSERT INTO `orderdetail` VALUES (2, 28, 1, 0, 0, 53);
INSERT INTO `orderdetail` VALUES (3, 28, 1, 0, 0, 53);
INSERT INTO `orderdetail` VALUES (4, 4, 1, 10288050, 0, 54);
INSERT INTO `orderdetail` VALUES (5, 25, 1, 950, 0, 55);

-- --------------------------------------------------------

-- 
-- Table structure for table `orders`
-- 

CREATE TABLE `orders` (
  `orders_id` int(11) NOT NULL auto_increment,
  `orders_customer_id` int(11) NOT NULL default '0',
  `orders_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `orders_status` tinyint(3) NOT NULL default '0',
  `last_modified` int(15) NOT NULL,
  PRIMARY KEY  (`orders_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=56 ;

-- 
-- Dumping data for table `orders`
-- 

INSERT INTO `orders` VALUES (55, 3, '2010-08-27 15:42:05', 0, 0);
INSERT INTO `orders` VALUES (54, 3, '2010-08-27 15:33:20', 0, 0);
INSERT INTO `orders` VALUES (53, 2, '2010-08-27 09:38:04', 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `price`
-- 

CREATE TABLE `price` (
  `dv_id` int(11) NOT NULL auto_increment,
  `dv_name` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL default '',
  `dv_dateadded` datetime default NULL,
  `parent_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`dv_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `price`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `product_new`
-- 

CREATE TABLE `product_new` (
  `pro_id` int(11) NOT NULL auto_increment,
  `products_id` int(11) NOT NULL default '0',
  `pro_sortorder` int(11) default '0',
  `pro_status` tinyint(3) default '0',
  `pro_dateadded` datetime default NULL,
  `language` varchar(4) default NULL,
  PRIMARY KEY  (`pro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `product_new`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `product_special`
-- 

CREATE TABLE `product_special` (
  `pro_id` int(11) NOT NULL auto_increment,
  `products_id` int(11) NOT NULL default '0',
  `pro_sortorder` int(11) default '0',
  `pro_status` tinyint(3) default '0',
  `pro_dateadded` datetime default NULL,
  `language` varchar(4) default NULL,
  PRIMARY KEY  (`pro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `product_special`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `pro_saleoff`
-- 

CREATE TABLE `pro_saleoff` (
  `pro_id` int(11) NOT NULL auto_increment,
  `products_id` int(11) NOT NULL default '0',
  `pro_sortorder` int(11) default '0',
  `pro_status` tinyint(3) default '0',
  `pro_dateadded` datetime default NULL,
  `language` varchar(4) default NULL,
  PRIMARY KEY  (`pro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `pro_saleoff`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tailieu`
-- 

CREATE TABLE `tailieu` (
  `doc_files_id` int(11) NOT NULL auto_increment,
  `doc_files_name` varchar(255) NOT NULL default '',
  `doc_files_description` varchar(255) default NULL,
  `doc_files_file` varchar(255) NOT NULL default '',
  `doc_files_type` varchar(25) default NULL,
  `doc_files_image` varchar(255) default NULL,
  `doc_files_status` tinyint(3) NOT NULL default '0',
  `doc_files_view` int(11) NOT NULL default '0',
  `doc_files_download` int(11) NOT NULL default '0',
  `doc_files_dateadded` datetime NOT NULL default '0000-00-00 00:00:00',
  `doc_files_categoriesid` int(11) default NULL,
  PRIMARY KEY  (`doc_files_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `tailieu`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_album`
-- 

CREATE TABLE `tbl_album` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `image` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `image_large` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `status` tinyint(3) NOT NULL default '0',
  `album_images_view` int(11) NOT NULL default '0',
  `subject` varchar(200) character set utf8 collate utf8_unicode_ci NOT NULL default '0',
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_modified` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `code` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sort` int(11) NOT NULL,
  `parent` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

-- 
-- Dumping data for table `tbl_album`
-- 

INSERT INTO `tbl_album` VALUES (12, '1', '', 'images/album/album_l12.jpg', 0, 0, '', '2010-10-22 00:19:21', '2010-10-22 00:19:21', '', 0, '2');
INSERT INTO `tbl_album` VALUES (13, '2', '', 'images/album/album_l13.jpg', 0, 0, '', '2010-10-22 00:19:44', '2010-10-22 00:20:04', '', 0, '2');
INSERT INTO `tbl_album` VALUES (14, '3', '', 'images/album/album_l14.jpg', 0, 0, '', '2010-10-22 00:19:51', '2010-10-22 00:19:51', '', 0, '2');
INSERT INTO `tbl_album` VALUES (15, '4', '', 'images/album/album_l15.jpg', 0, 0, '', '2010-10-22 00:20:12', '2010-10-22 00:20:12', '', 0, '2');
INSERT INTO `tbl_album` VALUES (16, '5', '', 'images/album/album_l16.jpg', 0, 0, '', '2010-10-22 00:20:23', '2010-10-22 00:20:23', '', 0, '2');
INSERT INTO `tbl_album` VALUES (17, 'Đối tác 1', 'images/album/album_s17.gif', 'images/album/album_l17.gif', 0, 0, '', '2010-10-22 00:39:09', '2010-10-22 00:39:09', '', 0, '3');
INSERT INTO `tbl_album` VALUES (18, 'Đối tác 2', 'images/album/album_s18.gif', 'images/album/album_l18.gif', 0, 0, '', '2010-10-22 00:39:21', '2010-10-22 00:39:21', '', 0, '3');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_album_category`
-- 

CREATE TABLE `tbl_album_category` (
  `categories_id` int(11) NOT NULL auto_increment,
  `parent` int(11) NOT NULL default '0',
  `categories_name` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `status` tinyint(3) NOT NULL default '0',
  `date_added` datetime default NULL,
  `last_modified` varchar(50) NOT NULL,
  `code` varchar(50) character set utf8 collate utf8_unicode_ci NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY  (`categories_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `tbl_album_category`
-- 

INSERT INTO `tbl_album_category` VALUES (2, 0, 'index', 0, '2010-10-15 16:19:21', '2010-10-15 16:19:21', '01', 2);
INSERT INTO `tbl_album_category` VALUES (3, 0, 'Đối tác', 0, '2010-10-15 20:31:37', '2010-10-15 20:31:37', '02', 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_config`
-- 

CREATE TABLE `tbl_config` (
  `asdasd` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `tbl_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_content`
-- 

CREATE TABLE `tbl_content` (
  `contents_id` int(11) NOT NULL auto_increment,
  `contents_name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `contents_content` longtext collate utf8_unicode_ci,
  `detail_short` mediumtext collate utf8_unicode_ci,
  `contents_note` varchar(255) collate utf8_unicode_ci default NULL,
  `contents_image` varchar(255) collate utf8_unicode_ci default NULL,
  `doc_categories_parentid` varchar(50) collate utf8_unicode_ci default NULL,
  `date_added` datetime default NULL,
  `last_modified` datetime default NULL,
  `status` tinyint(4) default NULL,
  `lang` varchar(50) collate utf8_unicode_ci default NULL,
  `sort` tinyint(2) default NULL,
  PRIMARY KEY  (`contents_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=117 ;

-- 
-- Dumping data for table `tbl_content`
-- 

INSERT INTO `tbl_content` VALUES (107, 'Thác nước nhân tạo - Tác phẩm nghệ thuật thiết kế tỉ mỉ', '<p style="text-align: left;">Khi n&oacute;i đến những th&aacute;c nước, ch&uacute;ng ta sẽ dễ d&agrave;ng li&ecirc;n tưởng đến một cảnh  vật h&ugrave;ng vĩ với những phiến đ&aacute; hoa khổng lồ v&agrave; những d&ograve;ng nước chảy mạnh đổ từ tr&ecirc;n cao xuống tung bọt nước trắng x&oacute;a.<br />\r\n<br />\r\nNếu bạn đ&atilde; từng một lần đứng trước vẻ đẹp h&ugrave;ng vĩ đ&oacute; của thi&ecirc;n nhi&ecirc;n chắc hẳn bạn sẽ ao ước c&oacute; thể tận hưởng cảm gi&aacute;c đ&oacute; h&agrave;ng ng&agrave;y, bởi tiếng nước chảy c&oacute;  t&aacute;c dụng xoa dịu căng thẳng v&agrave; mệt nhọc rất tốt.<br />\r\n</p>\r\n<div style="text-align: center;"><img width="400" height="300" alt="" style="border: 1px solid rgb(229, 229, 229); padding: 3px;" src="http://sonthuy.vn/images/stories/thac-nuoc/images_news_thacnuoc1_623201060444PMKSG_400x300_1.jpg" title="" /></div>\r\n<p style="text-align: left;"><br />\r\n<strong><em>Th&aacute;c nước nh&acirc;n tạo</em></strong><br />\r\nNg&agrave;y  nay, việc c&oacute; một th&aacute;c nước nh&acirc;n tạo cho ng&ocirc;i nh&agrave; th&acirc;n y&ecirc;u của bạn đ&atilde; kh&ocirc;ng c&ograve;n l&agrave; một điều g&igrave; đ&oacute; xa xỉ, bạn c&oacute; thể dễ d&agrave;ng c&oacute; cho ri&ecirc;ng m&igrave;nh một th&aacute;c nước t&ugrave;y theo sở th&iacute;ch m&agrave; kh&ocirc;ng qu&aacute; tốn k&eacute;m. Nhưng chắc hẳn sẽ c&oacute; nhiều c&acirc;u hỏi đặt ra khi bạn muốn sở hữu m&oacute;n đồ trang tr&iacute; hết sức đặc  biệt n&agrave;y.<br />\r\n<br />\r\nC&aacute;c th&aacute;c nước thường c&oacute; k&iacute;ch cỡ kh&aacute; lớn v&agrave; kh&aacute; nặng, họat động với c&aacute;c m&aacute;y bơm c&oacute; thể điều chỉnh được c&ocirc;ng suất. C&aacute;c loại th&aacute;c sử dụng chất liệu truyền thống như đ&aacute;, kim loại, thủy tinh hay xi măng thường kh&aacute; đẹp nhưng lại nặng v&agrave; kh&oacute; bảo dưỡng trong khi c&aacute;c loại th&aacute;c sử dụng vật liệu ti&ecirc;n tiến thường nhẹ v&agrave; thuận tiện khi sử dụng nhưng gi&aacute; th&agrave;nh lại cao hơn.</p>\r\n<div style="text-align: center;"><img width="400" height="300" alt="" style="border: 1px solid rgb(229, 229, 229); padding: 3px;" src="http://sonthuy.vn/images/stories/thac-nuoc/images_news_daiphunnuoc2_623201060523PMKSG_400x300_3.jpg" title="" /></div>\r\n<p style="text-align: left;">C&ugrave;ng  với sự ph&aacute;t triển của c&ocirc;ng nghệ, những chiếc bơm hiện nay c&oacute; k&iacute;ch cỡ ng&agrave;y c&agrave;ng nhỏ nhưng vẫn đảm bảo c&ocirc;ng suất đủ ti&ecirc;u chuẩn c&ugrave;ng với việc sử  dụng những chất liệu rẻ hơn nhưng c&oacute; độ bền cao lại gọn nhẹ. Gi&aacute; th&agrave;nh của những th&aacute;c nước nh&acirc;n tạo ng&agrave;y nay cũng kh&aacute; cạnh tranh, nhắm đến mọi đối tượng kh&aacute;ch h&agrave;ng n&ecirc;n bạn ho&agrave;n t&ograve;an c&oacute; thể chọn cho m&igrave;nh một th&aacute;c nước ưng &yacute; v&agrave; ph&ugrave; hợp với t&uacute;i tiền.<br />\r\n<br />\r\nSẽ thật sai lầm khi cho rằng  những th&aacute;c nước nh&acirc;n tạo sẽ chiếm rất nhiều diện t&iacute;ch trong kh&ocirc;ng gian sống của bạn. C&aacute;c th&aacute;c nước cũng đ&atilde; được quan t&acirc;m thiết kế với k&iacute;ch cỡ hết sức đa dạng, thậm ch&iacute; c&ograve;n c&oacute; loại th&aacute;c nước để b&agrave;n, hay để chặn giấy..nhưng cũng c&oacute; loại th&aacute;c k&iacute;ch cỡ lớn gi&agrave;nh cho kh&ocirc;ng gian s&acirc;n vườn.  H&atilde;y loại bỏ băn khoăn tr&ecirc;n ra khỏi suy nghĩ v&agrave; t&igrave;m cho m&igrave;nh một th&aacute;c nước ph&ugrave; hợp bằng c&aacute;ch tham khảo qua internet hay c&aacute;c tạp ch&iacute;.</p>\r\n<div style="text-align: center;"><img width="400" height="300" alt="" style="border: 1px solid rgb(229, 229, 229); padding: 3px;" src="http://sonthuy.vn/images/stories/thac-nuoc/images_news_daiphunnuoc3_623201060549PMKSG_400x300_2.jpg" title="" /></div>\r\n<p style="text-align: left;">C&aacute;c  th&aacute;c nước l&agrave; những t&aacute;c phẩm nghệ thuật được thiết kế tỉ mỉ v&agrave; chau chuốt, bơm nước l&agrave; th&agrave;nh phần thường hay gặp sự cố nhất. Để đảm bảo cho độ bền của th&aacute;c bạn cần đảm bảo giữ vệ sinh nước được sạch sẽ, kh&ocirc;ng để chất cặn bẩn bị h&uacute;t v&agrave;o bơm, đảm bảo nguồn điện ổ định th&igrave; tuổi thọ của th&aacute;c sẽ được đảm bảo hơn.<br />\r\n<br />\r\nNếu bạn nghĩ sẽ thật kh&oacute; để c&oacute; thể kết  hợp th&aacute;c với c&aacute;c đồ trang tr&iacute; kh&aacute;c th&igrave; quan niệm đ&oacute; đ&atilde; ho&agrave;n t&ograve;an lạc hậu khi m&agrave; ng&agrave;y nay c&aacute;c th&aacute;c nước đ&atilde; c&oacute; đầy đủ c&aacute;c phong c&aacute;ch kh&aacute;c nhau từ cổ điển đến hiện đại, từ ch&acirc;u &Aacute; đến ch&acirc;u &Acirc;u, từ d&acirc;n d&atilde; đến sang trọng, qu&yacute; ph&aacute;i&hellip;Điều đ&oacute; sẽ gi&uacute;p bạn dễ d&agrave;ng t&igrave;m được một th&aacute;c nước ph&ugrave; hợp với phong c&aacute;ch nội thất nh&agrave; m&igrave;nh.<br />\r\n<br />\r\nCuối c&ugrave;ng, động cơ m&aacute;y bơm  d&ugrave;ng trong th&aacute;c nước nh&acirc;n tạo thường c&oacute; c&ocirc;ng suất rất nhỏ n&ecirc;n năng lượng ti&ecirc;u thụ của th&aacute;c l&agrave; kh&ocirc;ng đ&aacute;ng kể. Bạn h&atilde;y nh&igrave;n v&agrave;o những mặt t&iacute;ch cực m&agrave; một th&aacute;c nước nhỏ c&oacute; thể mang lại để đưa ra quyết định trang  tr&iacute; cho ng&ocirc;i nh&agrave; của m&igrave;nh bằng m&oacute;n đồ trang tr&iacute; đặc biệt n&agrave;y, chắc chắn  bạn sẽ kh&ocirc;ng phải hối hận v&igrave; quyết định của m&igrave;nh. <br />\r\n<br />\r\n(NTO tổng hợp)</p>', '<p>Khi n&oacute;i đến những th&aacute;c nước, ch&uacute;ng ta sẽ dễ d&agrave;ng li&ecirc;n tưởng đến một cảnh  vật h&ugrave;ng vĩ với những phiến đ&aacute; hoa khổng lồ v&agrave; những d&ograve;ng nước chảy mạnh đổ từ tr&ecirc;n cao xuống tung bọt nước trắng x&oacute;a.</p>', NULL, NULL, '40', '2010-10-21 23:58:44', '2010-10-21 23:58:44', 0, '', 0);
INSERT INTO `tbl_content` VALUES (108, 'Ngôi nhà "đá" ở Bồ Đào Nha', '<div><img width="640" height="480" alt="Ngoi nha da o Bo Dao Nha" title="Ngoi nha da o Bo Dao Nha" src="http://sonthuy.vn/images/stories/tintuc/1798354c6b7c659b4b3_FlintstonesInspiredStoneHouse1.jpg" />&nbsp;</div>\r\n<p>B&ecirc;n cạnh những kiến tr&uacute;c mang đậm t&iacute;nh hiện đại như nh&agrave; thờ tương  lai, ga t&agrave;u điện ngầm tr&aacute;ng lệ, ng&ocirc;i nh&agrave; lấy &yacute; tưởng từ nước v&agrave; c&acirc;y&hellip; th&igrave;  cũng c&oacute; mẫu kiến tr&uacute;c mang d&aacute;ng dấp cổ điển như ng&ocirc;i nh&agrave; &ldquo;đ&aacute;&rdquo; dưới đ&acirc;y.  Lấy cảm hứng từ ng&ocirc;i nh&agrave; trong bộ phim hoạt h&igrave;nh &ldquo;Gia đ&igrave;nh  Flintstones&rdquo;, căn nh&agrave; l&agrave;m bằng đ&aacute; n&agrave;y được x&acirc;y dựng giữa hai tảng đ&aacute;  khổng lồ tr&ecirc;n sườn đồi ở v&ugrave;ng đồi n&uacute;i Fafe (Bồ Đ&agrave;o Nha). Giống như hầu  hết c&aacute;c ng&ocirc;i nh&agrave; đương đại, ng&ocirc;i nh&agrave; đ&aacute; n&agrave;y c&oacute; một cửa trước, một m&aacute;i  nh&agrave;, v&agrave; c&aacute;c cửa sổ nhưng do được x&acirc;y dựng ở nơi chỉ c&oacute; đ&aacute; v&agrave; cỏ n&ecirc;n c&agrave;ng  l&agrave;m nổi bật vẻ tiền sử của ng&ocirc;i nh&agrave; n&agrave;y.Do thiết kế kh&aacute;c thường của n&oacute;,  ng&ocirc;i nh&agrave; đ&atilde; thu h&uacute;t rất nhiều kh&aacute;ch du lịch từ khắp nơi tr&ecirc;n thế giới  đến chi&ecirc;m ngưỡng.</p>\r\n<p><br />\r\n<img width="640" height="480" alt="Ng&ocirc;i nh&agrave; đ&aacute; Nghệ Thuật ở Bồ Đ&agrave;o Nha" title="Ng&ocirc;i nh&agrave; đ&aacute; Nghệ Thuật ở Bồ Đ&agrave;o Nha" src="http://sonthuy.vn/images/stories/tintuc/1798354c6b7c700d93f_FlintstonesInspiredStoneHouse2.jpg" /></p>', '<p>B&ecirc;n cạnh những kiến tr&uacute;c mang đậm t&iacute;nh hiện đại như nh&agrave; thờ tương lai,  ga t&agrave;u điện ngầm tr&aacute;ng lệ, ng&ocirc;i nh&agrave; lấy &yacute; tưởng từ nước v&agrave; c&acirc;y&hellip; th&igrave; cũng  c&oacute; mẫu kiến tr&uacute;c mang d&aacute;ng dấp cổ điển như ng&ocirc;i nh&agrave; &ldquo;đ&aacute;&rdquo; dưới đ&acirc;y. Lấy  cảm hứng từ ng&ocirc;i nh&agrave; trong bộ phim hoạt h&igrave;nh &ldquo;Gia đ&igrave;nh Flintstones&rdquo;, căn  nh&agrave; l&agrave;m bằng đ&aacute; n&agrave;y được x&acirc;y dựng giữa hai tảng đ&aacute; khổng lồ tr&ecirc;n sườn  đồi ở v&ugrave;ng đồi n&uacute;i Fafe (Bồ Đ&agrave;o Nha). Giống như hầu hết c&aacute;c ng&ocirc;i nh&agrave;  đương đại, ng&ocirc;i nh&agrave; đ&aacute; n&agrave;y c&oacute; một cửa trước, một m&aacute;i nh&agrave;, v&agrave; c&aacute;c cửa sổ  nhưng do được x&acirc;y dựng ở nơi chỉ c&oacute; đ&aacute; v&agrave; cỏ n&ecirc;n c&agrave;ng l&agrave;m nổi bật vẻ  tiền sử của ng&ocirc;i nh&agrave; n&agrave;y.Do thiết kế kh&aacute;c thường của n&oacute;, ng&ocirc;i nh&agrave; đ&atilde; thu  h&uacute;t rất nhiều kh&aacute;ch du lịch từ khắp nơi tr&ecirc;n thế giới đến chi&ecirc;m ngưỡng.</p>', NULL, NULL, '40', '2010-10-22 00:01:39', '2010-10-22 00:05:08', 0, '', 0);
INSERT INTO `tbl_content` VALUES (103, 'Giới thiệu', '<p style="text-align: center;"><span style="font-size: x-large;"><span style="font-family: Verdana;"><strong><span style="color: rgb(0, 153, 0);">Đ&aacute; Cảnh Trần Kim</span></strong></span></span></p>\r\n<p style="text-align: center;">&nbsp;</p>\r\n<p style="text-align: center;"><span style="font-size: x-large;"><span style="font-family: Verdana;"><strong>&dagger;</strong></span></span></p>\r\n<p style="text-align: center;">&nbsp;</p>\r\n<ul>\r\n    <li><strong><span>Tư vấn, thiết kế, thi c&ocirc;ng s&acirc;n vườn, h&ograve;n non bộ, tiểu  cảnh, c&ocirc;ng vi&ecirc;n, nh&agrave; h&agrave;ng, kh&aacute;ch sạn, resort, cafe , bar, s&acirc;n vườn biệt  thự ....</span></strong></li>\r\n    <li><strong><span>Tư vấn &amp; xem phong thủy</span></strong></li>\r\n    <li><strong><span>Cung cấp c&aacute;c loại c&acirc;y xanh, c&acirc;y vỉa h&egrave; , cỏ c&aacute;c loại, bonsai, gốc c&acirc;y, c&acirc;y cổ thụ ...</span></strong></li>\r\n    <li><strong><span> Thiết kế, thi c&ocirc;ng hồ bơi, đ&agrave;i phun nước nghệ thuật, c&ocirc;ng vi&ecirc;n nước, th&aacute;c nước nh&acirc;n tạo, nhạc nước, hệ thống tưới ...</span></strong></li>\r\n    <li><strong><span>Chuy&ecirc;n cung cấp sỉ v&agrave; lẻ c&aacute;c loại đ&aacute; phong thủy, đ&aacute; nghệ thuật, đ&aacute; s&acirc;n vườn, đ&aacute; kiểng, đ&aacute; trang tr&iacute;, sỏi cuội c&aacute;c loại...</span></strong></li>\r\n</ul>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<div align="center"><input width="500" type="image" height="375" align="middle" src="http://sonthuy.vn/images/stories/son-thuy/hinh-anh-son-thuy2.jpg" alt="h&ograve;n non bộ đ&aacute; tự nhi&ecirc;n" /><br />\r\n<br />\r\n<div align="center"><br />\r\n<br />\r\n&nbsp;</div>\r\n</div>\r\n<div align="center">\r\n<div align="center">\r\n<div align="center">\r\n<div align="center">\r\n<div align="center">\r\n<div align="center">&nbsp;&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div align="left">\r\n<div align="left"><strong><font color="#ff0000">Nghệ Thuật Chơi Đ&aacute; Cảnh :</font></strong></div>\r\n<div align="left"><strong><font color="#ff0000">&nbsp;</font></strong></div>\r\n</div>\r\n<div align="left"><style type="text/css">p.MsoNormal, li.MsoNormal, div.MsoNormal { margin: 0in 0in 0.0001pt; font-size: 12pt; font-family: "Times New Roman"; }div.Section1 { page: Section1; }</style>\r\n<p class="MsoNormal" style="text-align: justify;"><strong><em><span style="font-size: 10pt; color: rgb(102, 102, 102);">Cũng như Bonsai, nghệ thuật chơi đ&aacute; cảnh xuất ph&aacute;t từ Trung hoa, dưới triều nh&agrave; Tống. V&agrave;o năm 1117, khi Tống Huy T&ocirc;ng được triều cống những vi&ecirc;n đ&aacute; đẹp từ v&ugrave;ng n&uacute;i Kh&aacute;nh Đ&aacute; thuộc huyện Từ Ch&acirc;u, sau đổi t&ecirc;n l&agrave; huyện Linh B&iacute;ch, th&igrave; vị ho&agrave;ng đế n&agrave;y bắt đầu say m&ecirc; chơi đ&aacute; v&agrave; d&acirc;n ch&uacute;ng cũng bắt đầu ch&uacute; &yacute; tới những vi&ecirc;n đ&aacute; đẹp.&nbsp;&nbsp;</span></em></strong></p>\r\n<p class="MsoNormal" style="text-align: justify;">&nbsp;</p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-size: 10pt;">Người chơi đ&aacute; nổi tiếng nhất thời đ&oacute; l&agrave; L&yacute; Dục với những &quot;sơn nghi&ecirc;n&quot; trứ danh vốn l&agrave; những vi&ecirc;n đ&aacute; đẹp c&oacute; h&igrave;nh n&uacute;i non v&agrave; được m&agrave;i trũng ở giữa để đựng mực. Những nghi&ecirc;n đ&aacute; đẹp n&agrave;y đ&atilde; được truyền từ đời vua n&agrave;y qua đời vua kh&aacute;c. Sau đ&oacute; Thi h&agrave;o T&ocirc; Đ&ocirc;ng Pha về nhậm chức tại Từ Ch&acirc;u cũng ưa sưu tầm đ&aacute; đẹp v&agrave; những b&agrave;i thơ vịnh đ&aacute; c&ugrave;ng tiếng tăm của &ocirc;ng đ&atilde; l&agrave;m hưng khởi phong tr&agrave;o chơi đ&aacute; cảnh. Năm 1086 Th&aacute;i th&uacute; Mễ Nguy&ecirc;n Chương về trấn nhậm gần Linh B&iacute;ch cũng l&agrave; người ưa đ&aacute; đẹp n&ecirc;n đ&atilde; c&ugrave;ng T&ocirc; Đ&ocirc;ng Pha đặt ra những nguy&ecirc;n tắc đầu ti&ecirc;n cho việc lựa chọn đ&aacute; cảnh. Theo c&aacute;c &ocirc;ng th&igrave; đ&aacute; đẹp phải c&oacute; đủ bốn ti&ecirc;u chuẩn l&agrave; <strong><em>Sấu, Thẩm, Lậu, Thấu</em></strong>&nbsp;</span></p>\r\n<p class="MsoNormal" style="text-align: justify;">&nbsp;</p>\r\n<p class="MsoNormal" style="text-align: justify;"><strong><em><span style="font-size: 10pt; color: maroon;">Sấu</span></em></strong><span style="font-size: 10pt; color: maroon;">:</span><span style="font-size: 10pt;"> gầy, gầy guộc nhưng phải rắn rỏi</span></p>\r\n<p class="MsoNormal" style="text-align: justify;"><strong><em><span style="font-size: 10pt; color: maroon;">Thẩm</span></em></strong><span style="font-size: 10pt;">: g&acirc;n sớ, nhăn nheo biểu hiện t&iacute;nh cỗ l&atilde;o, tang hải thương điền.</span></p>\r\n<p class="MsoNormal" style="text-align: justify;"><strong><em><span style="font-size: 10pt; color: maroon;">Lậu</span></em></strong><span style="font-size: 10pt;">: lồi l&otilde;m, hang hốc biểu hiện sự th&acirc;m u.</span></p>\r\n<p class="MsoNormal" style="text-align: justify;"><strong><em><span style="font-size: 10pt; color: maroon;">Thấu</span></em></strong><span style="font-size: 10pt; color: maroon;">:</span><span style="font-size: 10pt;"> c&oacute; hang lỗ thủng xuy&ecirc;n qua biểu thị sự triệt th&ocirc;ng ( th&ocirc;ng suốt).</span></p>\r\n<p class="MsoNormal" style="text-align: justify;">&nbsp;</p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-size: 10pt;">C&oacute; nghĩa l&agrave; vi&ecirc;n đ&aacute; phải l&agrave; một trong 6 dạng sau đ&acirc;y:</span></p>\r\n<p class="MsoNormal" style="text-align: justify;">&nbsp;</p>\r\n<p class="MsoNormal" style="text-align: justify;"><strong><em><span style="font-size: 10pt; color: maroon;">- Thanh t&uacute; thạch</span></em></strong><span style="font-size: 10pt;">: đ&aacute; c&oacute; h&igrave;nh d&aacute;ng đẹp, m&agrave;u sắc h&agrave;i h&ograve;a, v&acirc;n đ&aacute; mạch lạc.</span></p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-size: 10pt;">- <strong><em><span style="color: maroon;">C&ocirc; thuận thạch</span></em></strong>: tr&aacute;i với thanh t&uacute; thạch, đ&aacute; loại n&agrave;y gầy guc, cằn cỗi, tượng trưng cho sự khắc khổ.</span></p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-size: 10pt;">- <strong><em><span style="color: maroon;">Thần l&acirc;u thạch</span></em></strong>: đ&aacute; lồi l&otilde;m, c&oacute; hang hay lỗ.</span></p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-size: 10pt;">- <strong><em><span style="color: maroon;">Vi&ecirc;n hược thạch</span></em></strong>: đ&aacute; tr&ograve;n, nhẵn.</span></p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-size: 10pt;">- <strong><em><span style="color: maroon;">Tượng h&igrave;nh thạch</span></em></strong>: đ&aacute; c&oacute; h&igrave;nh người, vật, đồ vật hay cảnh quan tự nhi&ecirc;n.</span></p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-size: 10pt;">- <strong><em><span style="color: maroon;">Qu&aacute;i thạch:</span></em></strong> đ&aacute; c&oacute; h&igrave;nh th&ugrave; kỳ dị.</span></p>\r\n<div align="left"><br />\r\n<br />\r\n&nbsp;</div>\r\n</div>\r\n<div align="center"><img width="500" height="373" alt="" title="" src="http://sonthuy.vn/images/stories/sonthuy3.jpg" /> <br />\r\n<br />\r\n<img width="500" height="375" alt="" title="" src="http://sonthuy.vn/images/stories/da%20nghe%20thuat/hinhdadep.jpg" /></div>\r\n<div align="center"><img width="500" height="373" title="" src="http://sonthuy.vn/images/stories/sontruy4.jpg" alt="" /></div>\r\n<p>&nbsp;</p>', '<p><strong><span><br />\r\n</span></strong></p>', NULL, NULL, '35', '2010-10-17 23:01:00', '2010-10-21 22:44:10', 0, '', 1);
INSERT INTO `tbl_content` VALUES (109, 'Người đi tìm sự hồi sinh cho miền đá tai mèo', '<table width="1" cellspacing="0" cellpadding="3" border="0" align="left">\r\n    <tbody>\r\n        <tr>\r\n            <td align="left" class="pic_explain"><img alt="" title="" src="http://sonthuy.vn/images/stories/da%20nghe%20thuat/14_ban1305.jpg" id="StoryAvatar" style="border-width: 0px; height: 146px; width: 180px;" /></td>\r\n        </tr>\r\n        <tr>\r\n            <td><span id="AvatarDesc" class="image_desc">&quot;Bạn tri kỷ&quot; của Tiến sỹ Vũ Văn Bằng - m&aacute;y địa bức xạ.</span></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p><span class="sapeau_box"> </span></p>\r\n<div><span id="lbBody" class="text_box">\r\n<div><font size="2">Tuổi 70, với khoa học chưa phải l&uacute;c đến với th&uacute; tao nh&atilde; &quot;khi ch&eacute;n rượu, khi cuộc cờ&quot;. Nhưng ở độ tuổi đ&oacute; vẫn đảm đương Chủ tịch Hội đồng quản trị, trực tiếp theo đuổi chuy&ecirc;n ng&agrave;nh địa bức xạ, ra Bắc v&agrave;o  Nam  với m&aacute;y đo tia đất, kh&aacute;m ph&aacute; dưới g&oacute;c độ khoa học c&aacute;c hiện tượng b&iacute; ẩn của địa chất th&igrave; Tiến sỹ Vũ Văn Bằng lại l&agrave;m nhiều người chột dạ... </font></div>\r\n<div><font size="2">&nbsp;</font></div>\r\n</span></div>\r\n<p align="justify"><span id="lbBody" class="text_box">\r\n<p><font size="2">Chột dạ v&igrave; kh&ocirc;ng &iacute;t người ngay ng&aacute;y lo cho sức khoẻ của &ocirc;ng. &quot;Nhỡ m&agrave; ng&atilde; tr&ecirc;n n&uacute;i th&igrave; ai địu về, tuổi ấy khối người ngồi nh&agrave;  c&ograve;n ng&atilde; huống chi đi biền biệt&quot; - c&ocirc; ch&aacute;u g&aacute;i lo lắng cho &ocirc;ng m&igrave;nh. C&aacute;i  chột dạ của người th&acirc;n l&agrave; c&oacute; cơ sở. C&ograve;n với nh&agrave; khoa học địa bức xạ Vũ Văn Bằng, mọi thứ kh&ocirc;ng c&oacute; g&igrave; kh&ocirc;ng thể nếu &ocirc;ng c&ograve;n sức, c&ograve;n đi được, nghe được, n&oacute;i được. </font></p>\r\n<p><font size="2">Thế n&ecirc;n c&aacute;ch Tết &iacute;t ng&agrave;y, người ta vừa thấy &ocirc;ng lom khom đo tia đất ở khu đất giải ph&oacute;ng mặt bằng thuộc chợ 19-12 (H&agrave; Nội), &iacute;t h&ocirc;m sau lại thấy &ocirc;ng đ&atilde; rục rịch ngược miền n&uacute;i ph&iacute;a Bắc, nơi nhiều đồng b&agrave;o Th&aacute;i, Dao, T&agrave;y trỏ v&agrave;o giếng nước trong bản n&oacute;i: &quot;Đ&oacute; l&agrave; giếng &ocirc;ng Bằng&quot;...</font></p>\r\n<p><font size="2">Tiếp x&uacute;c với ch&uacute;ng t&ocirc;i, Tiến sĩ Vũ Bằng giải th&iacute;ch: Tia đất l&agrave; một dạng vật chất bao gồm tất cả những tia ph&aacute;t ra từ vỏ cứng  của tr&aacute;i đất v&agrave; lan tỏa l&ecirc;n mặt đất dưới dạng bức xạ - dạng trường. N&oacute;i  c&aacute;ch kh&aacute;c, đ&oacute; l&agrave; những tia được sản sinh bởi hiện tượng bức xạ của những vật chất kh&aacute;c nhau từ dưới đất, l&agrave; một trong những th&agrave;nh phần của m&ocirc;i trường sống. Do vậy th&ocirc;ng qua nguy&ecirc;n l&yacute; tia đất - địa bức xạ với thiết bị tương ứng c&oacute; thể t&igrave;m được c&aacute;c đối tượng b&iacute; ẩn dưới mặt đất như:  kho&aacute;ng sản c&oacute; &iacute;ch, quặng mỏ, đ&aacute; qu&yacute;, nước ngầm, hang động, nứt đất, nứt  đ&ecirc;, sự cố của c&aacute;c c&ocirc;ng tr&igrave;nh ngầm (cống thải, đường ống cấp tho&aacute;t nước,  ống dẫn dầu, gas, c&aacute;p điện bị nứt vỡ r&ograve; rỉ...), kể cả khảo cổ...</font></p>\r\n<p><font size="2">N&oacute;i về lĩnh vực nghi&ecirc;n cứu khiến tuổi gi&agrave; &quot;cũng thấy kh&ocirc;ng mệt mỏi&quot;, Tiến sỹ Bằng n&oacute;i với ch&uacute;ng t&ocirc;i rằng, từ trước đến nay con người v&agrave; giới khoa học mới chỉ t&igrave;m hiểu v&agrave; biết nhiều về tia vũ trụ.  C&ograve;n tia đất chưa được quan t&acirc;m nghi&ecirc;n cứu, mặc d&ugrave; ảnh hưởng bất lợi của  n&oacute; tới sức khỏe con người kh&ocirc;ng hề nhỏ, kh&ocirc;ng hề thua k&eacute;m c&aacute;c t&aacute;c nh&acirc;n g&acirc;y bệnh kh&aacute;c. Trong khi đ&oacute; tia đất c&oacute; mặt ở hầu khắp mọi nơi v&agrave; tia đất  độc hại xuất hiện nhiều hơn gấp nhiều lần tia đất c&oacute; lợi. Theo quan niệm truyền thống c&oacute; &quot;đất l&agrave;nh, đất dữ, địa linh nh&acirc;n kiệt&quot;... Điều đ&oacute; đ&uacute;ng, nhưng đ&oacute; kh&ocirc;ng phải do quan niệm t&acirc;m linh thần th&aacute;nh hay ma quỷ m&agrave;  cần hiểu về g&oacute;c độ khoa học, đ&oacute; ch&iacute;nh l&agrave; &quot;tia đất&quot;. </font></p>\r\n<p><font size="2"><strong>&Aacute;p tai, quỵ gối miền đ&aacute; tai m&egrave;o</strong></font></p>\r\n<p><font size="2">Tiến sỹ Bằng n&oacute;i l&yacute; do lập C&ocirc;ng ty Tia Đất xuất ph&aacute;t bởi &quot;nhiều năm đi c&ocirc;ng t&aacute;c miền n&uacute;i, t&ocirc;i thấy đồng b&agrave;o ngh&egrave;o ở tận H&agrave; Giang, Cao Bằng, Y&ecirc;n B&aacute;i, điển h&igrave;nh như miền đ&aacute; Đồng Văn, họ chia nhau từng g&aacute;o nước mưa, chắt chiu như sữa mẹ. T&ocirc;i hiểu, họ đang khao kh&aacute;t c&oacute; nguồn nước ngọt chừng n&agrave;o, trong khi đ&oacute; qu&aacute; tr&igrave;nh nghi&ecirc;n cứu về địa bức xạ, t&ocirc;i c&oacute; thể t&igrave;m được mạch nước ngầm bằng tia đất&quot;. </font></p>\r\n<table cellspacing="2" cellpadding="0" border="0" rules="none" align="center" frame="void" style="width: 20px; height: 20px;">\r\n    <tbody>\r\n        <tr>\r\n            <td><img width="600" height="450" title="" alt="" src="http://sonthuy.vn/images/stories/da%20nghe%20thuat/nuida_taomeo.jpg" /></td>\r\n        </tr>\r\n        <tr>\r\n            <td><font color="#808080" size="2">Bằng phương ph&aacute;p tia đất, ph&aacute;t hiện mạch nước ngầm, nhiều hồ nước treo ở v&ugrave;ng n&uacute;i ph&iacute;a Bắc h&igrave;nh th&agrave;nh.</font></td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p><font size="2">&Yacute; tưởng đấy, n&oacute; l&agrave; hiện thực cuộc sống nh&acirc;n sinh nhưng  c&ocirc;ng việc kh&ocirc;ng khởi đầu dễ d&agrave;ng. Viện Địa chất cũng cử c&aacute;n bộ l&ecirc;n đ&acirc;y quần thảo h&agrave;ng chục năm trời t&igrave;m giải ph&aacute;p cấp nguồn nước cho đồng b&agrave;o nhưng kết quả vẫn hạn chế. Giải ph&aacute;p x&acirc;y hồ treo được xem khả dĩ, nhưng vấn đề l&agrave; t&igrave;m mạch nước đ&acirc;u để bơm v&agrave;o hồ treo. &Ocirc;ng Bằng trở th&agrave;nh người  giải đề to&aacute;n &quot;m&egrave;o đeo nhạc&quot;, vậy l&agrave; tr&ecirc;n v&aacute;ch đ&aacute; tai m&egrave;o miền Đồng Văn,  nh&agrave; khoa học ch&acirc;n d&eacute;p tổ ong lạch cạch m&aacute;y tia d&ograve; dẫm từng vị tr&iacute;.&nbsp; </font></p>\r\n<p><font size="2">&quot;Kinh nghiệm cho thấy, ở n&uacute;i cao cũng c&oacute; thể c&oacute; mạch nước ngầm đạt ti&ecirc;u chuẩn cao&quot; - &ocirc;ng tư duy. Nhưng tuần đầu ti&ecirc;n xem ra c&ocirc;ng sức bỏ ra chỉ để &quot;khởi động&quot;. Thời gian tiếp theo, c&aacute;i kh&ocirc; r&aacute;m v&ugrave;ng  n&uacute;i tiếp tục thử th&aacute;ch. </font></p>\r\n<p><font size="2">Ai cũng biết, &yacute; tưởng x&acirc;y hồ nước treo tr&ecirc;n v&aacute;ch đ&aacute; tai m&egrave;o đẹp hơn tranh vẽ, nhưng l&agrave;m sao để đưa h&agrave;ng tấn xi măng, sắt th&eacute;p leo n&uacute;i, v&agrave; lấy đ&acirc;u nguồn nước đủ để pha trộn. Đ&oacute; l&agrave; thời gian như nằm gai nếm mật, cũng c&oacute; người t&iacute;nh bỏ cuộc. </font></p>\r\n<p><font size="2">&quot;Nhưng t&ocirc;i nghĩ, b&agrave; con d&acirc;n bản đ&atilde; b&aacute;m trụ đ&acirc;y bao đời, tại sao m&igrave;nh chừng đ&oacute; kh&ocirc;ng chịu được. Chưa trả lời được b&agrave;i to&aacute;n, tất chưa thể y&ecirc;n l&ograve;ng&quot; - &ocirc;ng trăn trở. </font></p>\r\n<p><font size="2">Nhiều đ&ecirc;m, &ocirc;ng k&ecirc; chiếc m&aacute;y soi b&ecirc;n đ&aacute; tai m&egrave;o, nằm &aacute;p  tai h&agrave;ng tiếng đồng hồ d&ograve; t&iacute;n hiệu. C&oacute; thể nguồn nước nằm ở độ s&acirc;u dăm chục m&eacute;t, trăm m&eacute;t hoặc s&acirc;u hơn, d&ograve; kh&ocirc;ng kỹ dễ bị lọt. Trong khi đ&oacute;, m&aacute;y định vị b&aacute;m chủ như vật duy nhất, bởi bất kỳ người thứ hai n&agrave;o khi đụng đến m&aacute;y cũng như g&agrave; mắc t&oacute;c, kh&ocirc;ng thể giải đ&aacute;p, đọc được &quot;suy nghĩ&quot; của m&aacute;y. Mạch nước ph&aacute;t lộ, m&ugrave;a h&egrave; năm đ&oacute;, cao nguy&ecirc;n Đồng Văn được x&acirc;y dựng 3 hồ chứa nước. </font></p>\r\n<p><font size="2">Nay th&igrave; ở H&agrave; Giang, Cao Bằng, L&agrave;o Cai, những hồ treo hay giếng nước v&ugrave;ng cao xuất hiện nhiều hơn, c&oacute; v&ugrave;ng người ta đặt cho giếng nước, hồ treo l&agrave; hồ &ocirc;ng Bằng, giếng &ocirc;ng Bằng. C&aacute;ch gọi ấy, dĩ nhi&ecirc;n cũng l&agrave; th&oacute;i quen đồng b&agrave;o, c&ograve;n với Tiến sỹ, n&oacute; như động lực khiến  &ocirc;ng chưa thể t&igrave;m đến với cờ, với rượu thư thản ở tuổi &quot;xưa nay hiếm&quot;. </font></p>\r\n<p><font size="2"><strong>Khoa học kh&ocirc;ng c&oacute; chỗ cho &aacute;c mộng</strong></font></p>\r\n<p><font size="2">M&aacute;y định vị tia đất nhập khẩu từ đ&acirc;u? T&ocirc;i cứ băn khoăn, v&agrave; giả sử nếu &ocirc;ng mở lớp truyền đạt cho những người kế vị, hẳn l&agrave;  c&aacute;ch hay? Tuy nhi&ecirc;n, thực tế chiếc m&aacute;y c&oacute; h&igrave;nh th&ugrave; như ăng ten cỡ nhỏ n&agrave;y ho&agrave;n to&agrave;n kh&ocirc;ng c&oacute; xuất xứ từ nước n&agrave;o cả, đ&oacute; l&agrave; sản phẩm tự s&aacute;ng chế dựa tr&ecirc;n c&aacute;c nghi&ecirc;n cứu khoa học, trong đ&oacute; c&oacute; nhiều năm tu nghiệp ở Ba Lan. </font></p>\r\n<p><font size="2">M&aacute;y n&agrave;y c&oacute; thể d&ograve; mạch nước ngầm, định vị độ s&acirc;u, hướng nước chảy, lưu lượng nước. N&oacute; cũng c&oacute; thể &quot;đọc&quot; nơi c&oacute; kho&aacute;ng sản,  c&oacute; thể ở độ s&acirc;u tr&ecirc;n dưới trăm m&eacute;t v&agrave; ch&iacute;nh khả năng n&agrave;y đ&atilde; gi&uacute;p nhiều tỉnh v&ugrave;ng cao như Cao Bằng t&igrave;m ra c&aacute;c mỏ quặng qu&yacute; hiếm. </font></p>\r\n<p><font size="2">Ở g&oacute;c độ kh&aacute;c: x&aacute;c định mồ mả, h&agrave;i cốt liệt sỹ, c&aacute;ch định vị bằng tia đất được khẳng định c&oacute; cơ sở khoa học cao, ho&agrave;n to&agrave;n kh&aacute;c với c&aacute;ch m&agrave; nhiều nh&agrave; ngoại cảm đang l&agrave;m l&agrave; dựa v&agrave;o thuyết duy t&acirc;m.</font></p>\r\n<p><font size="2">Hỏi chuyện n&agrave;y, t&ocirc;i sực nhớ mấy ng&agrave;y trước Tết Kỷ Sửu,  &ocirc;ng Tiến sĩ 70 tuổi c&ograve;n d&ograve; m&aacute;y ngo&agrave;i khu vực chợ 19-12 (H&agrave; Nội). &Ocirc;ng n&oacute;i rằng, nếu kh&ocirc;ng x&aacute;c định bằng m&aacute;y tia đất, c&oacute; thể nhầm lẫn hoặc để s&oacute;t xương cốt người đ&atilde; hy sinh tại đ&acirc;y. </font></p>\r\n<p><font size="2">H&ocirc;m đ&oacute; trời mưa ph&ugrave;n, t&ocirc;i ra ng&oacute; thấy &ocirc;ng vẫn loay hoay dưới r&atilde;nh c&ocirc;ng nh&acirc;n vừa đ&agrave;o bới, &ocirc;ng n&oacute;i ph&aacute;t hiện th&ecirc;m mấy bộ h&agrave;i cốt nữa dưới c&aacute;c lớp đất đ&aacute;. T&ocirc;i giật m&igrave;nh, kh&ocirc;ng biết nh&agrave; khoa học c&oacute; biết l&uacute;c ấy đ&atilde; 28 Tết rồi kh&ocirc;ng. B&ecirc;n c&ocirc;ng sở, trước v&agrave; sau, họ đ&atilde; đ&oacute;ng cửa im l&igrave;m nghỉ Tết. C&ograve;n &ocirc;ng... Nh&agrave; khoa học, t&ocirc;i hiểu th&ecirc;m điều &quot;vị nh&acirc;n sinh&quot; ở đ&acirc;y rằng, chỉ c&oacute; t&agrave;i năng, chỉ c&oacute; thiết bị hiện đại th&ocirc;i chưa đủ m&agrave; phải c&oacute; niềm đam m&ecirc;. </font></p>\r\n<p><font size="2">&Ocirc;ng n&oacute;i rằng, kh&ocirc;ng c&oacute; &aacute;c mộng n&agrave;o sau những lần t&igrave;m h&agrave;i cốt hay t&igrave;m mạch nước ngầm, kho&aacute;ng sản cả. &quot;M&igrave;nh l&agrave;m dựa tr&ecirc;n cơ sở khoa học v&agrave; sự đam m&ecirc; thực thụ, v&igrave; cuộc sống người ngh&egrave;o th&igrave; chỉ c&oacute; nhiệt huyết, t&iacute;nh ch&iacute;nh x&aacute;c cao độ chứ l&agrave;m g&igrave; c&oacute; &aacute;c mộng&quot; - &ocirc;ng n&oacute;i như lẽ hiển nhi&ecirc;n của nghiệp giải m&atilde; b&iacute; ẩn m&igrave;nh đang đeo đuổi</font></p>\r\n</span></p>', '<p><span class="sapeau_box"><span id="lbTeaser">Tiến sỹ Vũ Văn Bằng  n&oacute;i l&yacute; do lập C&ocirc;ng ty Tia Đất xuất ph&aacute;t bởi: &quot;Nhiều năm đi c&ocirc;ng t&aacute;c miền n&uacute;i, t&ocirc;i thấy đồng b&agrave;o ngh&egrave;o ở H&agrave; Giang, Cao Bằng, Y&ecirc;n B&aacute;i, điển h&igrave;nh như miền đ&aacute; bỏng r&aacute;t cao nguy&ecirc;n Đồng Văn, họ chắt chiu từng g&aacute;o nước mưa qu&yacute; như sữa mẹ. T&ocirc;i hiểu, họ khao kh&aacute;t c&oacute; nguồn nước ngọt, trong khi qu&aacute; tr&igrave;nh nghi&ecirc;n cứu về địa bức xạ, t&ocirc;i đ&atilde; th&agrave;nh c&ocirc;ng trong việc t&igrave;m được mạch nước ngầm bằng tia đất&quot;. &Yacute; tưởng đấy, n&oacute; l&agrave; hiện thực  cuộc sống nh&acirc;n sinh nhưng c&ocirc;ng việc m&agrave; &ocirc;ng đ&atilde; thực hiện kh&ocirc;ng phải dễ d&agrave;ng. </span></span></p>', NULL, NULL, '40', '2010-10-22 00:02:50', '2010-10-22 00:03:24', 0, '', 0);
INSERT INTO `tbl_content` VALUES (110, 'Làm nhà theo phong thủy', '<div>\r\n<div>Qu&aacute; tr&igrave;nh &ldquo;tam sao thất bản&rdquo; v&agrave; biến đổi theo c&aacute;c yếu tố kinh tế &ndash;  x&atilde; hội khiến c&oacute; l&uacute;c Phong Thủy c&oacute; vẻ rất phức tạp v&agrave; bị một số yếu tố m&ecirc;  t&iacute;n l&agrave;m thi&ecirc;n lệch.&nbsp; <br />\r\n<br />\r\n<img width="576" height="419" src="http://sonthuy.vn/images/stories/kien-thuc-phong-thuy/nhatheophongthuy.jpg" title="" alt="" /></div>\r\n</div>\r\n<div>\r\n<div><strong><br />\r\nNước chảy c&oacute; nguồn</strong><br />\r\n<br />\r\nThực ra Phong Thủy cũng như c&aacute;c ng&agrave;nh khoa học kh&aacute;c, đều xuất ph&aacute;t  từ những yếu tố rất cơ bản, đơn giản v&agrave; thiết thực. Nếu kh&ocirc;ng thiết thực  cho đời sống người d&acirc;n v&agrave; vu vơ m&ecirc; t&iacute;n th&igrave; khoa phong thủy đ&atilde; kh&ocirc;ng tồn  tại được cho đến ng&agrave;y nay v&igrave; người ta chỉ tin v&agrave; thực h&agrave;nh theo những  g&igrave; c&oacute; lợi cho m&igrave;nh, gia đ&igrave;nh m&igrave;nh v&agrave; cộng đồng.<br />\r\n<br />\r\nV&iacute; dụ, việc treo một tấm gương nhỏ trước cửa thực ra chỉ l&agrave; động t&aacute;c  mang t&iacute;nh b&igrave;nh ổn t&acirc;m l&yacute;, c&ograve;n ng&ocirc;i nh&agrave; đ&oacute; tốt hay xấu phải x&eacute;t rất to&agrave;n  diện. Những b&agrave;i &ldquo;thuốc an thần&rdquo; như vậy cũng kh&ocirc;ng hề c&oacute; trong cội  nguồn xuất ph&aacute;t của phong thủy, nhưng c&oacute; lẽ&hellip; v&ocirc; thưởng v&ocirc; phạt n&ecirc;n người  ta cứ treo gương!<br />\r\n<br />\r\nV&igrave; vậy, c&aacute;c gia chủ cần ph&acirc;n biệt đ&acirc;u l&agrave; giải ph&aacute;p Phong Thủy, đ&acirc;u  l&agrave; t&iacute;n ngưỡng d&acirc;n gian. Việc sắp xếp một ng&ocirc;i nh&agrave; sao cho tho&aacute;ng m&aacute;t,  thuận tiện sinh hoạt, hợp l&yacute; đối với c&aacute;c th&agrave;nh vi&ecirc;n cư tr&uacute; lu&ocirc;n l&agrave; điều  cần l&agrave;m; nhưng việc c&uacute;ng b&aacute;i, d&aacute;n b&ugrave;a&hellip; lại thuộc về t&iacute;n ngưỡng d&acirc;n gian,  t&ugrave;y theo tập tục v&agrave; đức tin của mỗi v&ugrave;ng, mỗi người. Ch&uacute;ng ta t&ocirc;n trọng  nhưng kh&ocirc;ng lẫn lộn với c&aacute;c giải ph&aacute;p Phong Thủy đ&iacute;ch thực.<br />\r\n<br />\r\nC&oacute; lẽ cũng n&ecirc;n lần về cội nguồn ph&aacute;t sinh ra Phong Thủy để hiểu r&otilde;  bản chất của khoa học n&agrave;y. Sự ph&aacute;t sinh của Phong Thủy li&ecirc;n quan đến  nhiều nguy&ecirc;n nh&acirc;n x&atilde; hội, trong đ&oacute; tập trung v&agrave;o ba vấn đề ch&iacute;nh sau  đ&acirc;y:<br />\r\n<br />\r\nThứ nhất l&agrave; sự x&eacute;t đo&aacute;n h&igrave;nh thế &ndash; một th&aacute;i độ tự nhi&ecirc;n của con  người trong qu&aacute; tr&igrave;nh vận động, giao tiếp với m&ocirc;i trường thi&ecirc;n nhi&ecirc;n v&agrave;  x&atilde; hội. Gặp một ai, sự vật g&igrave; người ta cũng thường xem x&eacute;t để chọn lựa  c&aacute;i tốt nhất trong khả năng c&oacute; thể.<br />\r\n<br />\r\nThứ nh&igrave; l&agrave; đạo hiếu của người sống muốn tưởng niệm người chết, muốn  c&acirc;n bằng t&acirc;m l&yacute; v&agrave; phần n&agrave;o răn dạy người kh&aacute;c, cũng l&agrave; một ước muốn cho  bản th&acirc;n m&igrave;nh mai sau. Do đ&oacute; trong Phong Thủy cổ xưa c&oacute; rất nhiều c&aacute;ch  xem Thủy Khẩu, Long Mạch&hellip; cho mồ mả (&acirc;m phần) m&agrave; việc &aacute;p dụng cho thực  tế hiện nay c&ograve;n nhiều mơ hồ, nặng về cảm t&iacute;nh. Rồi những yếu tố n&agrave;y bị  một số s&aacute;ch vở trộn lẫn với Phong Thủy Dương Trạch (nh&agrave; cửa cho người  sống) l&agrave;m tăng th&ecirc;m t&iacute;nh kỳ b&iacute;, phức tạp.<br />\r\n<br />\r\nThứ ba l&agrave; c&aacute;c truyền tụng v&agrave; thuật số t&iacute;nh to&aacute;n mang t&iacute;nh tập tục,  được đ&uacute;c kết qua nhiều thời kỳ, mong muốn gặp l&agrave;nh tr&aacute;nh dữ, mang t&iacute;nh  d&acirc;n tộc học v&agrave; văn h&oacute;a địa phương. V&igrave; vậy c&aacute;c nước &Aacute; Đ&ocirc;ng như Việt Nam,  Trung Quốc, Nhật Bản đều c&oacute; c&aacute;c nguy&ecirc;n tắc phong thủy ri&ecirc;ng.<br />\r\n<br />\r\n<strong>Những ti&ecirc;u ch&iacute; cơ bản</strong><br />\r\n<br />\r\nĐể l&agrave;m nh&agrave; theo một tiến tr&igrave;nh Phong Thủy b&agrave;i bản, đ&ograve;i hỏi gia chủ  phải c&oacute; những kiến thức nhất định v&agrave; sự chọn lựa c&aacute;c giải ph&aacute;p sao cho  ph&ugrave; hợp ho&agrave;n cảnh mỗi gia đ&igrave;nh, mỗi ng&ocirc;i nh&agrave;. C&aacute;c giải ph&aacute;p Phong Thủy  lu&ocirc;n phải được tiến h&agrave;nh tr&ecirc;n nền tảng 5 ti&ecirc;u ch&iacute;, cũng l&agrave; 5 t&iacute;nh chất  cơ bản của Phong Thủy:<br />\r\n<br />\r\n- T&iacute;nh Tổng hợp: Xem x&eacute;t rất nhiều phương diện để tạo lập m&ocirc;i trường  sống tốt nhất. X&eacute;t về chữ nghĩa: Phong l&agrave; gi&oacute;, t&iacute;nh Động, thuộc dương.  Thủy l&agrave; nước mang t&iacute;nh Tĩnh, thuộc &acirc;m. Gi&oacute; &ndash; nước, &acirc;m - dương phải tương  giao th&igrave; Thổ Trạch mới h&agrave;i h&ograve;a.<br />\r\n<br />\r\n- T&iacute;nh Linh hoạt: Kh&ocirc;ng c&oacute; ng&ocirc;i nh&agrave; hay cuộc đất n&agrave;o l&agrave; tốt hoặc xấu  ho&agrave;n to&agrave;n m&agrave; phải t&ugrave;y thuộc v&agrave;o truờng hợp cụ thể, thậm ch&iacute; c&oacute; thể xấu  với người n&agrave;y nhưng người kh&aacute;c lại thấy tốt, thấy ph&ugrave; hợp với m&igrave;nh. Khi  gặp t&igrave;nh huống bất lợi, lu&ocirc;n c&oacute; c&aacute;c giải ph&aacute;p khắc phục sao cho &iacute;t t&agrave;n  ph&aacute; m&ocirc;i trường, dựa v&agrave;o thi&ecirc;n nhi&ecirc;n, giảm thiểu c&ocirc;ng sức, chi ph&iacute;.<br />\r\n<br />\r\n- T&iacute;nh Qu&acirc;n b&igrave;nh: Lu&ocirc;n giữ tỷ lệ hợp l&yacute; của c&aacute;c th&agrave;nh phần kh&ocirc;ng  gian, kh&ocirc;ng qu&aacute; thi&ecirc;n lệch, đảm bảo c&acirc;n bằng &acirc;m dương, động tĩnh trong  m&ocirc;i trường ở. Cần x&aacute;c định c&acirc;n bằng chứ kh&ocirc;ng phải c&agrave;o bằng, phải c&oacute;  ch&iacute;nh phụ.<br />\r\n<br />\r\n- T&iacute;nh Ổn định: Phong Thủy vốn xuất ph&aacute;t từ đời sống định cư của d&acirc;n  l&agrave;m n&ocirc;ng nghiệp, do đ&oacute; chọn đất cất nh&agrave; cha &ocirc;ng ta lu&ocirc;n nhắm đến tương  lai xa, mong con ch&aacute;u được ph&aacute;t triển vững bền. Sự ổn định trong Phong  Thủy hiện đại cần hiểu l&agrave;: giảm thiểu biến cố, ph&aacute;t triển l&acirc;u d&agrave;i.<br />\r\n<br />\r\n- T&iacute;nh T&acirc;m linh: Xem trọng yếu tố t&iacute;n ngưỡng v&agrave; đời sống tinh thần.  Hướng nội v&agrave; lu&ocirc;n tưởng nhớ tiền nh&acirc;n (thờ c&uacute;ng, gi&aacute;o dục truyền thống).  Phong Thủy cũng l&agrave; một &ldquo;liệu ph&aacute;p&rdquo; t&acirc;m l&yacute; hiệu quả n&ecirc;n vẫn c&oacute; một số  thủ ph&aacute;p mang t&iacute;nh &ldquo; an thần &ldquo;nhằm tạo t&acirc;m l&yacute; thoải m&aacute;i cho người cư  ngụ.</div>\r\n</div>', '<p>Qu&aacute; tr&igrave;nh &ldquo;tam sao thất bản&rdquo; v&agrave; biến đổi theo c&aacute;c yếu tố kinh tế &ndash;  x&atilde; hội khiến c&oacute; l&uacute;c Phong Thủy c&oacute; vẻ rất phức tạp v&agrave; bị một số yếu tố m&ecirc;  t&iacute;n l&agrave;m thi&ecirc;n lệch...&nbsp;</p>', NULL, NULL, '41', '2010-10-22 00:09:16', '2010-10-22 00:09:57', 0, '', 0);
INSERT INTO `tbl_content` VALUES (111, 'Nhà nhiều cửa có nên không ?', '<div>Đối với nhiều ng&ocirc;i nh&agrave; c&oacute; diện t&iacute;ch rộng, đ&ocirc;i khi gia chủ muốn bố tr&iacute; cửa đi mở ra nhiều mặt nh&agrave; nhằm tho&aacute;ng kh&iacute;......&nbsp;</div>\r\n<div><img width="117" height="121" src="http://sonthuy.vn/images/stories/kien-thuc-phong-thuy/nhanhieucua.jpg" title="" alt="" />&nbsp;</div>\r\n<div>\r\n<p>&nbsp;Thực chất ng&ocirc;i nh&agrave; n&agrave;o cũng c&oacute; nhiều cửa (cửa trước, sau, b&ecirc;n...) t&ugrave;y theo h&igrave;nh thế đất đai v&agrave; t&iacute;nh chất sử dụng. Nhưng cần lưu &yacute;, khoa phong thủy ph&acirc;n biệt rạch r&ograve;i ch&iacute;nh - phụ v&agrave; lu&ocirc;n x&aacute;c định mỗi ng&ocirc;i nh&agrave;, mỗi gia đ&igrave;nh chỉ n&ecirc;n c&oacute; một bộ cửa ch&iacute;nh. C&aacute;c cửa cổng, cửa hậu, cửa b&ecirc;n... đều chỉ l&agrave; cửa phụ. Nh&agrave; c&oacute; được vượng kh&iacute; hay kh&ocirc;ng l&agrave; ở hướng v&agrave; k&iacute;ch thước của cửa ch&iacute;nh. Trường hợp cửa ch&iacute;nh mở ra gặp nhiều bất lợi (hướng nắng, gi&oacute;, điểm nh&igrave;n...) sẽ phải điều chỉnh cửa hoặc x&acirc;y b&iacute;t hẳn cửa ch&iacute;nh v&agrave; mở cửa ch&iacute;nh ở một nơi kh&aacute;c. Cửa ch&iacute;nh thường l&agrave; cửa lớn nhất trong nh&agrave;. Tuy nhi&ecirc;n, việc mở cửa kh&aacute;c ở một số nơi l&agrave; điều kh&ocirc;ng thể. Khi đ&oacute; cần phải tư vấn kiến tr&uacute;c sư để c&oacute; giải ph&aacute;p ph&ugrave; hợp.</p>\r\n</div>\r\n<div align="justify">&nbsp;</div>\r\n<p align="justify">Việc ki&ecirc;ng kỵ nh&agrave; mở nhiều của xuất ph&aacute;t từ c&acirc;u &quot;Đa m&ocirc;n tắc đa khẩu&quot;, tức l&agrave; nh&agrave; c&oacute; nhiều cửa ắt c&oacute; nhiều miệng h&uacute;t kh&iacute;, l&agrave;m cho nắng v&agrave; gi&oacute; v&agrave;o nh&agrave; từ nhiều hướng cả tốt lẫn xấu, g&acirc;y ra rối loạn trường kh&iacute;, người đi ra đi v&agrave;o g&acirc;y phức tạp trong kiểm so&aacute;t an ninh. Tuy nhi&ecirc;n, nếu nh&agrave; c&oacute; nhiều cửa đi nhưng ph&iacute;a ngo&agrave;i chỉ c&oacute; một cổng chung th&igrave; vẫn tốt, miễn l&agrave; bố tr&iacute; cổng v&agrave; cửa theo nguy&ecirc;n tắc h&igrave;nh phễu - trước rộng, sau hẹp - để thu h&uacute;t nguồn kh&iacute; v&agrave;o nh&agrave;. Cần lưu &yacute; c&aacute;c cửa kh&ocirc;ng n&ecirc;n thẳng h&agrave;ng nhau. C&aacute;c cửa nếu đ&atilde; lỡ mở nhiều th&igrave; c&oacute; thể điều chỉnh bằng c&aacute;ch đặt chậu cảnh hay vật trang tr&iacute; để ph&acirc;n t&aacute;n v&agrave; ngăn bớt cường độ d&ograve;ng kh&iacute; dẫn v&agrave;o nh&agrave;. Cũng n&ecirc;n d&ugrave;ng loại cửa k&iacute;nh c&oacute; d&aacute;n mờ một phần (nhất l&agrave; với hướng nắng gắt) hoặc đ&oacute;ng hẳn cửa lại nếu kh&ocirc;ng sử dụng thường xuy&ecirc;n.</p>\r\n<p>Đối với nhiều ng&ocirc;i nh&agrave; c&oacute; diện t&iacute;ch rộng, đ&ocirc;i khi gia chủ muốn bố tr&iacute; cửa đi mở ra nhiều mặt nh&agrave; nhằm tho&aacute;ng kh&iacute;. Lại c&oacute; nhiều người cho rằng x&eacute;t về mặt phong thủy, đ&oacute; l&agrave; điều kh&ocirc;ng tốt. Tuy nhi&ecirc;n, ở trường hợp n&agrave;o cũng c&oacute; giải ph&aacute;p.</p>', '<p>Đối với nhiều ng&ocirc;i nh&agrave; c&oacute; diện t&iacute;ch rộng, đ&ocirc;i khi gia chủ muốn bố tr&iacute; cửa đi mở ra nhiều mặt nh&agrave; nhằm tho&aacute;ng kh&iacute;...... </p>', NULL, NULL, '41', '2010-10-22 00:10:22', '2010-10-22 00:10:22', 0, '', 0);
INSERT INTO `tbl_content` VALUES (112, 'Chọn hướng cho ngôi nhà.', '<div>Ng&ocirc;i nh&agrave; lu&ocirc;n l&agrave; chốn dừng ch&acirc;n b&igrave;nh an cho mỗi người sau những  ng&agrave;y l&agrave;m việc vất v&atilde;. V&igrave; vậy khi thiết kế người ta kh&ocirc;ng chỉ ch&uacute; trọng  về h&igrave;nh thức v&agrave; mẩu m&atilde;. M&agrave;u sắc v&agrave; phương hướng cũng chiếm một vị tr&iacute;  rất quan trọng.</div>\r\n<div><img width="350" height="227" src="http://sonthuy.vn/images/stories/kien-thuc-phong-thuy/chonhuongchongoinha3.jpg" title="" alt="" />   <br />\r\nĐặc biệt l&agrave; hướng cửa, cửa kh&ocirc;ng chỉ đơn thuần l&agrave; nơi để ra v&agrave;o m&agrave; n&oacute;  c&ograve;n tạo n&ecirc;n một kh&ocirc;ng gian tho&aacute;ng m&aacute;t cho ng&ocirc;i nh&agrave; của bạn.<br />\r\nSự kết hợp h&agrave;i h&ograve;a giữa hướng v&agrave; m&agrave;u sắc nơi cửa ch&iacute;nh sẽ mang lại nhiều  may mắn v&agrave; tốt l&agrave;nh cho ng&ocirc;i nh&agrave;. Một lối đi rộng r&atilde;i, một m&agrave;u sắc ph&ugrave;  hợp rất tốt trong thiết kế phong thủy.<br />\r\nC&oacute; nhiều người, khi lựa chọn hướng v&agrave; m&agrave;u sắc cho cửa đ&atilde; nghĩ rằng điều  n&agrave;y chẳng c&oacute; g&igrave; quan trọng v&igrave; hướng ng&ocirc;i nh&agrave; mới l&agrave; thứ thiết yếu nhất.  Điều đ&oacute; thật sai lầm v&igrave; trong phong thủy mỗi chi tiết của ng&ocirc;i nh&agrave; đều  mang một yếu tố ri&ecirc;ng của n&oacute;. Đối với cửa thuộc hướng T&acirc;y nam hoặc Đ&ocirc;ng  bắc, thuộc h&agrave;nh thổ th&igrave; những gam m&agrave;u thuộc mộc v&agrave; thủy l&agrave; kh&ocirc;ng ph&ugrave;  hợp. M&agrave;u xanh l&aacute; c&acirc;y hay m&agrave;u xanh nước biển l&agrave; m&agrave;u bạn cần n&ecirc;n tr&aacute;nh.<br />\r\nĐối với c&aacute;nh cửa nằm ở hướng Đ&ocirc;ng hoặc Đ&ocirc;ng nam, thuộc h&agrave;nh mộc, bạn cần  tr&aacute;nh sơn m&agrave;u trắng. Cũng kh&ocirc;ng sử dụng cửa l&agrave;m bằng kim loại, thuộc  h&agrave;nh kim bởi kim khắc mộc Đồng thời, bạn cũng cần tr&aacute;nh sơn cửa m&agrave;u đỏ,  bởi hỏa sẽ l&agrave;m suy kiệt năng lượng mộc ở đ&acirc;y. Chọn cửa gỗ, sơn m&agrave;u xanh  l&aacute; l&agrave; tốt nhất.<br />\r\n<br />\r\n<img width="250" height="318" src="http://sonthuy.vn/images/stories/kien-thuc-phong-thuy/chonhuongchongoinha1.jpg" title="" alt="" /><br />\r\nTr&aacute;nh sơn m&agrave;u trắng cho hướng Đ&ocirc;ng<br />\r\nHướng T&acirc;y v&agrave; T&acirc;y bắc thuộc h&agrave;nh kim v&igrave; vậy m&agrave;u đỏ l&agrave; m&agrave;u bạn cần n&ecirc;n  tr&aacute;nh. Tốt nhất l&agrave; sử dụng m&agrave;u trắng, x&aacute;m, bạc. M&agrave;u xanh biển rất ph&ugrave;  hợp với của hướng Bắc v&igrave; hướng Bắc thuộc h&agrave;nh thủy. Tuy nhi&ecirc;n m&agrave;u xanh  nước biển sẽ rất tối kỵ khi bạn d&ugrave;ng n&oacute; cho c&aacute;nh cửa hướng Nam.<br />\r\n<br />\r\n<img width="250" height="322" src="http://sonthuy.vn/images/stories/kien-thuc-phong-thuy/chonhuongchongoinha2.jpg" title="" alt="" /><br />\r\nCửa m&agrave;u trắng rất hợp với hướng Bắc</div>', '<p>Ng&ocirc;i nh&agrave; lu&ocirc;n l&agrave; chốn dừng ch&acirc;n b&igrave;nh an cho mỗi người sau những  ng&agrave;y l&agrave;m việc vất v&atilde;. V&igrave; vậy khi thiết kế người ta kh&ocirc;ng chỉ ch&uacute; trọng  về h&igrave;nh thức v&agrave; mẩu m&atilde;. M&agrave;u sắc v&agrave; phương hướng cũng chiếm một vị tr&iacute;  rất quan trọng.</p>', NULL, NULL, '41', '2010-10-22 00:10:53', '2010-10-22 00:10:53', 0, '', 0);
INSERT INTO `tbl_content` VALUES (113, 'Thông tin tuyển dụng', '<p>Chưa c&oacute; nội dung</p>', '<p>Chưa c&oacute; nội dung</p>', NULL, NULL, '42', '2010-10-22 00:25:19', '2010-10-22 00:25:19', 0, '', 0);
INSERT INTO `tbl_content` VALUES (114, 'Liên hệ', '<p><b>Văn ph&ograve;ng:</b> Metropolitan Building 235 Đồng Khởi Q.1 TP.HCM<br />\r\n<b>Chi nh&aacute;nh : </b> Saigon HTP, Lot I2 D1 Saigon Hi-Tech Park Q.9 TP.HCM<br />\r\n<b> ĐT: </b> (848)  823 3372 - 000 0000 - 000 0000 - <b>Fax: </b> 823-3373</p>', '', NULL, NULL, '43', '2010-10-22 00:26:37', '2010-10-22 00:26:37', 0, '', 0);
INSERT INTO `tbl_content` VALUES (115, 'Phòng kinh doanh', 'test@yahoo.com', '', NULL, NULL, '44', '2010-10-22 00:34:40', '2010-10-22 00:34:40', 0, '', 0);
INSERT INTO `tbl_content` VALUES (116, 'Phòng kỹ thuật', 'test@yahoo.com', '', NULL, NULL, '44', '2010-10-22 00:35:11', '2010-10-22 00:35:11', 0, '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_content_category`
-- 

CREATE TABLE `tbl_content_category` (
  `categories_id` int(11) NOT NULL auto_increment,
  `parent` int(11) NOT NULL default '0',
  `categories_name` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `status` tinyint(3) NOT NULL default '0',
  `doc_categories_desc` text character set utf8 collate utf8_unicode_ci,
  `date_added` datetime default NULL,
  `code` varchar(50) character set utf8 collate utf8_unicode_ci default NULL,
  `last_modified` datetime default NULL,
  `lang` varchar(20) character set utf8 collate utf8_unicode_ci default 'vn',
  `sort` int(11) default NULL,
  `image` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`categories_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

-- 
-- Dumping data for table `tbl_content_category`
-- 

INSERT INTO `tbl_content_category` VALUES (35, 0, 'Lời Ngỏ', 0, NULL, '2010-10-14 22:45:28', 'aboutus', '2010-10-14 22:45:28', 'vn', 1, NULL);
INSERT INTO `tbl_content_category` VALUES (40, 0, 'Tin tức', 0, NULL, '2010-10-21 23:57:11', 'news', '2010-10-21 23:57:11', '', 0, NULL);
INSERT INTO `tbl_content_category` VALUES (41, 0, 'Phong thủy', 0, NULL, '2010-10-22 00:07:50', 'phongthuy', '2010-10-22 00:07:50', '', 0, NULL);
INSERT INTO `tbl_content_category` VALUES (42, 0, 'Tuyển dụng', 0, NULL, '2010-10-22 00:24:46', 'tuyendung', '2010-10-22 00:24:46', '', 0, NULL);
INSERT INTO `tbl_content_category` VALUES (43, 0, 'Liên hệ', 0, NULL, '2010-10-22 00:25:50', 'contact', '2010-10-22 00:25:50', '', 0, NULL);
INSERT INTO `tbl_content_category` VALUES (44, 0, 'Hỗ trợ trực tuyến', 0, NULL, '2010-10-22 00:33:46', 'yahoo', '2010-10-22 00:33:46', '', 0, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_product`
-- 

CREATE TABLE `tbl_product` (
  `products_id` int(11) NOT NULL auto_increment,
  `products_code` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `products_name` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `products_image` varchar(64) character set utf8 collate utf8_unicode_ci default NULL,
  `products_image_large` varchar(64) character set utf8 collate utf8_unicode_ci default NULL,
  `products_price` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `products_date_added` datetime default '0000-00-00 00:00:00',
  `products_date_modified` datetime default NULL,
  `products_status` tinyint(3) default '0',
  `products_ordered` int(11) default '0',
  `products_include` text character set utf8 collate utf8_unicode_ci,
  `products_shortdescription` text character set utf8 collate utf8_unicode_ci,
  `products_description` text character set utf8 collate utf8_unicode_ci,
  `categories_id` int(11) default '0',
  `providers_id` int(11) default NULL,
  `donvi_id` int(11) default '0',
  `language` varchar(4) character set utf8 collate utf8_unicode_ci default NULL,
  `products_loai` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `products_xuatxu` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `baohanh` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `products_pro` varchar(255) character set utf8 collate utf8_unicode_ci default '0',
  `subject` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `video` text character set utf8 collate utf8_unicode_ci,
  PRIMARY KEY  (`products_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

-- 
-- Dumping data for table `tbl_product`
-- 

INSERT INTO `tbl_product` VALUES (18, '', 'Mẹ ôm con', '/product_s18.jpg', NULL, '', '2010-10-21 23:25:30', '2010-10-21 23:25:30', 0, 0, NULL, '', '<div style="text-align: center;"><img width="350" height="467" src="http://sonthuy.vn/images/stories/da-phong-thuy/mecon1.jpg" title="" alt="" /></div>\r\n<div align="center">\r\n<div style="text-align: center;">T&aacute;c phẩm do Sơn Thủy thực hiện</div>\r\n</div>\r\n<div align="center">\r\n<div style="text-align: center;"><img width="350" height="467" src="http://sonthuy.vn/images/stories/da%20nghe%20thuat/mecon.jpg" title="" alt="" /></div>\r\n</div>', 130, 0, 0, '', NULL, NULL, '', '0', '', NULL);
INSERT INTO `tbl_product` VALUES (19, '', 'Mẫu hòn non bộ', '/product_s19.jpg', NULL, '', '2010-10-21 23:27:53', '2010-10-21 23:27:53', 0, 0, NULL, '', '<div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/non-bo/nb%2013.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/non-bo/b2.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img width="743" height="421" alt="" src="http://sonthuy.vn/images/stories/non-bo/nb%2016_1.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/non-bo/nb%2019.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/non-bo/nb%202.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img width="716" height="438" alt="" src="http://sonthuy.vn/images/stories/non-bo/nb%2020.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/non-bo/nb%2021.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/non-bo/nb%2024_1.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/non-bo/nb%203.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/non-bo/nb04.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img width="663" height="663" alt="" src="http://sonthuy.vn/images/stories/non-bo/nb1.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;"><img width="710" height="649" alt="" src="http://sonthuy.vn/images/stories/non-bo/nb2.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/non-bo/nb%2018.jpg" /></div>', 131, 0, 0, '', NULL, NULL, '', '0', '', NULL);
INSERT INTO `tbl_product` VALUES (16, '', 'Một số mẫu Đá Nghệ Thuật', '/product_s16.jpg', NULL, '', '2010-10-21 23:16:23', '2010-10-21 23:16:23', 0, 0, NULL, '', '<div align="center">\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/gallery/phucloctho.jpg" /></div>\r\n</div>\r\n<table cellspacing="0" cellpadding="3" border="0" summary="" style="width: 100%; border-collapse: collapse;">\r\n    <tbody>\r\n        <tr valign="top" align="center">\r\n            <td width="100%">\r\n            <div style="text-align: center;">&nbsp;</div>\r\n            <div>&nbsp;</div>\r\n            <p style="text-align: center;">Ph&uacute;c&nbsp; Lộc Thọ <br />\r\n            &nbsp;</p>\r\n            </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;"><img width="640" height="480" src="http://sonthuy.vn/images/stories/gallery/chuatroi.jpg" title="" alt="" /> </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;">Ch&uacute;a Trời </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/gallery/quy%20thach.jpg" /> </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;">Quy thạch </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/gallery/long%20chau.jpg" /> </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;">Long Ch&acirc;u </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/gallery/thieu%20nu.jpg" /> </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;">Thiếu Nữ </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/gallery/bungtinh.jpg" /> </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;">Bung Tinh&nbsp; </td>\r\n        </tr>\r\n        <tr valign="top">\r\n            <td>\r\n            <div>\r\n            <div align="center">\r\n            <div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/gallery/thach_hoquyen.jpg" /></div>\r\n            </div>\r\n            <p style="text-align: center;">&nbsp;</p>\r\n            </div>\r\n            </td>\r\n        </tr>\r\n        <tr valign="top" align="center">\r\n            <td style="text-align: center;">Thạch Hổ Quyền&nbsp;</td>\r\n        </tr>\r\n    </tbody>\r\n</table>', 130, 0, 0, '', NULL, NULL, '', '0', '', NULL);
INSERT INTO `tbl_product` VALUES (20, '', 'Hổ- Đại Bàng', '/product_s20.JPG', NULL, '', '2010-10-21 23:34:49', '2010-10-21 23:34:49', 0, 0, NULL, '', '<div style="text-align: center;"><img width="640" height="480" src="http://sonthuy.vn/images/stories/non-bo/IMG_1310.JPG" title="" alt="" />&nbsp;</div>\r\n<p style="text-align: center;"><img width="637" height="478" src="http://sonthuy.vn/images/stories/non-bo/img_0566.jpg" title="" alt="" /></p>', 131, 0, 0, '', NULL, NULL, '', '0', '', NULL);
INSERT INTO `tbl_product` VALUES (21, '', 'Tiểu cảnh nước trong nhà phố', '/product_s21.jpg', NULL, '', '2010-10-21 23:35:50', '2010-10-21 23:35:50', 0, 0, NULL, '', '<br />\r\n<table class="contentpaneopen">\r\n    <tbody>\r\n        <tr>\r\n            <td valign="top">\r\n            <div>\r\n            <div style="text-align: center;"><span style="font-size: medium;"><img width="350" height="251" src="http://sonthuy.vn/images/stories/tieu-canh/tieucanhnuoc002.jpg" title="" alt="" /></span>   </div>\r\n            <p style="text-align: center;" class="Lead"><span style="font-size: medium;">Theo  phong c&aacute;ch ch&acirc;u &Aacute;, trang tr&iacute; tiểu cảnh nước trong s&acirc;n vườn c&oacute; nhiều điểm kh&aacute;c với ch&acirc;u &Acirc;u. Người ch&acirc;u &Aacute; n&oacute;i chung rất trọng phong thủy n&ecirc;n lu&ocirc;n tu&acirc;n theo những quy tắc nhất định.</span></p>\r\n            <table cellspacing="0" cellpadding="3" border="0" align="center" style="width: 1px;">\r\n                <tbody>\r\n                    <tr>\r\n                        <td style="text-align: center;"><img width="300" height="200" alt="" style="border: 1px solid black;" src="http://sonthuy.vn/images/stories/tieu-canh-01/tc1.jpg" title="" /></td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td class="Image" style="text-align: center;">Tạo d&ograve;ng chảy bằng những con giống, b&igrave;nh gốm.</td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            <p style="text-align: center;" class="Normal"><span style="font-size: medium;">Người  ch&acirc;u &Aacute; thường trang tr&iacute; mặt nước với phong c&aacute;ch nước tĩnh thay v&igrave; động như ch&acirc;u &Acirc;u. Họ cũng cầu kỳ hơn, thể hiện r&otilde; ở việc trang tr&iacute; theo dạng non bộ. Non bộ m&ocirc; phỏng lại m&ocirc; h&igrave;nh tự nhi&ecirc;n với non nước, c&acirc;y cối, c&ocirc;ng  tr&igrave;nh kiến tr&uacute;c, cảnh sinh hoạt...</span></p>\r\n            <table cellspacing="0" cellpadding="3" border="0" align="center" style="width: 396px;">\r\n                <tbody>\r\n                    <tr>\r\n                        <td style="text-align: center;"><img width="190" height="150" alt="" style="border: 1px solid black;" src="http://sonthuy.vn/images/stories/tieu-canh-01/tc5.jpg" title="" /></td>\r\n                        <td style="text-align: center;"><img width="190" height="150" alt="" style="border: 1px solid black;" src="http://sonthuy.vn/images/stories/tieu-canh-01/tc2.jpg" title="" /></td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td class="Image" style="text-align: center;">Non bộ được m&ocirc; phỏng cảnh sinh hoạt rất sinh động.</td>\r\n                        <td class="Image" style="text-align: center;">C&acirc;y thế, sinh vật cảnh cũng được đưa v&agrave;o tiểu cảnh nước.</td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            <p style="text-align: center;" class="Normal"><span style="font-size: medium;">Phong  c&aacute;ch trang tr&iacute; tiểu cảnh nước, non bộ của người ch&acirc;u &Aacute; bị ảnh hưởng nhiều bởi phong thủy. V&igrave; vậy nếu trang tr&iacute; vườn theo phong c&aacute;ch ch&acirc;u &Aacute;, bạn kh&ocirc;ng thể l&agrave;m bừa. Nếu l&agrave;m theo dạng non bộ, c&acirc;y thế được sử dụng nhiều. Để tạo ra kh&ocirc;ng gian n&uacute;i non, th&aacute;c, suối giống thật, việc chọn lựa c&acirc;y cối, sinh vật cảnh cũng rất quan trọng.</span></p>\r\n            <table cellspacing="0" cellpadding="3" border="0" align="center" style="width: 320px;">\r\n                <tbody>\r\n                    <tr>\r\n                        <td style="text-align: center;"><img width="190" height="150" alt="" style="border: 1px solid black;" src="http://sonthuy.vn/images/stories/tieu-canh-01/tc8.jpg" title="" /></td>\r\n                        <td style="text-align: center;"><img width="190" height="150" alt="" style="border: 1px solid black;" src="http://sonthuy.vn/images/stories/tieu-canh-01/tc9.jpg" title="" /></td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td style="text-align: center;"><img width="190" height="150" alt="" src="http://sonthuy.vn/images/stories/tieu-canh-01/tc10.jpg" style="border: 1px solid black;" /></td>\r\n                        <td style="text-align: center;"><img width="190" height="150" alt="" src="http://sonthuy.vn/images/stories/tieu-canh-01/tc7.jpg" style="border: 1px solid black;" /></td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td colspan="2" class="Image" style="text-align: center;">Những sản phẩm b&aacute;n sẵn đưa nước v&agrave;o vườn.</td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            <p style="text-align: center;" class="Normal"><span style="font-size: medium;">Bạn  n&ecirc;n chọn c&acirc;y nhỏ hoặc vừa phải để trang tr&iacute; v&igrave; nếu c&acirc;y to sẽ l&agrave;m cho n&uacute;i của bạn biến th&agrave;nh h&ograve;n đ&aacute;. C&aacute; trong suối cũng n&ecirc;n chọn những loại b&eacute;  để d&ograve;ng suối c&oacute; cảm gi&aacute;c rộng hơn. Nếu c&oacute; trang tr&iacute; th&ecirc;m c&aacute;c m&ocirc; h&igrave;nh bằng sứ như nh&agrave; cửa, động vật, người v&agrave;o th&igrave; n&ecirc;n ch&uacute; &yacute; để ch&uacute;ng tỷ lệ với nhau.</span></p>\r\n            <table cellspacing="0" cellpadding="3" border="0" align="center" style="width: 346px;">\r\n                <tbody>\r\n                    <tr>\r\n                        <td style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/tieu-canh-01/tc4.jpg" style="border: 1px solid black;" /></td>\r\n                        <td style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/tieu-canh-01/tc3.jpg" style="border: 1px solid black;" /></td>\r\n                    </tr>\r\n                    <tr>\r\n                        <td colspan="2" class="Image" style="text-align: center;">Kết hợp đ&aacute;, nước, c&acirc;y thế, sinh vật cảnh.</td>\r\n                    </tr>\r\n                </tbody>\r\n            </table>\r\n            <p style="text-align: center;" class="Normal"><span style="font-size: medium;">Với  kh&ocirc;ng gian vườn nhỏ, nếu kh&ocirc;ng c&oacute; điều kiện trang tr&iacute; non bộ, suối, th&aacute;c th&igrave; bạn vẫn c&oacute; thể đưa nước v&agrave;o khu vườn nhỏ bằng những sản phẩm l&agrave;m sẵn. C&oacute; thể l&agrave; th&aacute;c nước nhỏ được chế t&aacute;c sẵn chỉ việc đem về bầy, những v&ograve;i nước nhỏ chảy ra từ ống tre hay những bể nước được đục thủ c&ocirc;ng bằng đ&aacute; nguy&ecirc;n khối.</span></p>\r\n            </div>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>', 132, 0, 0, '', NULL, NULL, '', '0', '', NULL);
INSERT INTO `tbl_product` VALUES (22, '', 'Mẫu Vườn xinh', '/product_s22.jpg', NULL, '', '2010-10-21 23:36:33', '2010-10-21 23:36:33', 0, 0, NULL, '', '<br />\r\n<table class="contentpaneopen">\r\n    <tbody>\r\n        <tr>\r\n            <td valign="top">\r\n            <div>\r\n            <div style="text-align: center;"><img width="660" height="NaN" alt="Mau vuon xinh" src="http://sonthuy.vn/images/stories/tieu-canh/tc%2094.jpg" title="Mau vuon xinh" />&nbsp;</div>\r\n            </div>\r\n            <div>\r\n            <div style="text-align: center;">&nbsp;</div>\r\n            </div>\r\n            <div>\r\n            <div>\r\n            <div style="text-align: center;"><img width="660" height="NaN" alt="tieu canh dep" src="http://sonthuy.vn/images/stories/tieu-canh/tc%20125.jpg" title="tieu canh dep" />\\</div>\r\n            </div>\r\n            </div>\r\n            <p style="text-align: center;">&nbsp;</p>\r\n            <div><img width="660" height="457" alt="tieu canh trong nha" src="http://sonthuy.vn/images/stories/tieu-canh/tc%2032.jpg" title="tieu canh trong nha" />&nbsp;</div>\r\n            <div style="text-align: center;">&nbsp;</div>\r\n            <div style="text-align: center;"><img width="660" height="NaN" alt="tieu canh non bo" src="http://sonthuy.vn/images/stories/tieu-canh/tc%20177.jpg" title="tieu canh non bo" /></div>\r\n            <div align="center">\r\n            <div style="text-align: center;">&nbsp;</div>\r\n            </div>\r\n            <div style="text-align: center;"><img width="660" height="NaN" alt="tieu canh kho" src="http://sonthuy.vn/images/stories/tieu-canh/tc01.jpg" title="tieu canh kho" /></div>\r\n            <div style="text-align: center;">&nbsp;</div>\r\n            <div style="text-align: center;"><img width="660" height="441" alt="da nghe thuat" src="http://sonthuy.vn/images/stories/tieu-canh/tc%2034.jpg" title="da nghe thuat" />&nbsp;</div>\r\n            <p style="text-align: center;">&nbsp; &nbsp;</p>\r\n            <div align="left"><img width="660" height="NaN" alt="tieu canh hien dai" src="http://sonthuy.vn/images/stories/tieu-canh/tc%2049.jpg" title="tieu canh hien dai" />&nbsp;</div>\r\n            <div style="text-align: center;"><img width="660" height="NaN" alt="" src="http://sonthuy.vn/images/stories/tieu-canh/tc_1.jpg" title="" />&nbsp;</div>\r\n            <div style="text-align: center;">&nbsp;</div>\r\n            <div align="center">\r\n            <div align="center">\r\n            <div style="text-align: center;"><img width="660" height="NaN" alt="" src="http://sonthuy.vn/images/stories/tieu-canh/tc%20210.jpg" title="" />&nbsp;</div>\r\n            <div style="text-align: center;">&nbsp;</div>\r\n            <div style="text-align: center;"><img width="660" height="NaN" alt="" src="http://sonthuy.vn/images/stories/tieu-canh/tc%2052.jpg" title="" /></div>\r\n            </div>\r\n            </div>\r\n            <div align="center">\r\n            <div style="text-align: center;">&nbsp;</div>\r\n            </div>\r\n            <div style="text-align: center;"><img width="660" height="471" alt="" src="http://sonthuy.vn/images/stories/tieu-canh/tc03.jpg" title="" /></div>\r\n            <div align="center">\r\n            <div style="text-align: center;">&nbsp;</div>\r\n            </div>\r\n            <div style="text-align: center;"><img width="660" height="NaN" alt="" src="http://sonthuy.vn/images/stories/tieu-canh/tc02.jpg" title="" /></div>\r\n            <div align="center">\r\n            <p style="text-align: center;">&nbsp;</p>\r\n            <div align="left">&nbsp;<img width="660" height="576" alt="" src="http://sonthuy.vn/images/stories/tieu-canh/tc010.jpg" title="" /></div>\r\n            </div>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>', 132, 0, 0, '', NULL, NULL, '', '0', '', NULL);
INSERT INTO `tbl_product` VALUES (23, '', 'Cảnh quan sân vườn phong cách hiện đại', '/product_s23.jpg', NULL, '', '2010-10-21 23:38:11', '2010-10-21 23:38:11', 0, 0, NULL, '', '<table class="contentpaneopen">\r\n    <tbody>\r\n        <tr>\r\n            <td valign="top">\r\n            <div style="text-align: left;">Sau đ&acirc;y l&agrave; một số mẫu thiết kế cảnh quan s&acirc;n vườn hiện đại m&agrave; qu&yacute; quị c&oacute; thể tham khảo.</div>\r\n            <div style="text-align: left;"><img width="660" height="440" src="http://sonthuy.vn/images/stories/canh-quan-san-vuon/landscape01.jpg" title="Cảnh quan s&acirc;n vườn hiện đại" alt="Cảnh quan s&acirc;n vườn hiện đại" />&nbsp;</div>\r\n            <div style="text-align: left;">&nbsp;</div>\r\n            <div style="text-align: left;"><img width="660" height="371" src="http://sonthuy.vn/images/stories/canh-quan-san-vuon/landscape02.jpg" title="San vuon phong cach hien dai" alt="San vuon phong cach hien dai" />&nbsp;</div>\r\n            <div style="text-align: left;"><img width="660" height="456" src="http://sonthuy.vn/images/stories/canh-quan-san-vuon/landscape03.jpg" title="Canh quan san vuon dep hien dai" alt="Canh quan san vuon dep hien dai" /></div>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p style="text-align: left;">&nbsp;</p>', 133, 0, 0, '', NULL, NULL, '', '0', '', NULL);
INSERT INTO `tbl_product` VALUES (24, '', 'Nguyên tắc thiết kế cảnh quan sân vườn.', '/product_s24.jpg', NULL, '', '2010-10-21 23:39:00', '2010-10-21 23:39:00', 0, 0, NULL, '', '<table class="contentpaneopen">\r\n    <tbody>\r\n        <tr>\r\n            <td valign="top">\r\n            <p style="text-align: center;"><img width="400" height="295" src="http://sonthuy.vn/images/stories/canh-quan-san-vuon/landscape-design-photo-pool.jpg" title="" alt="" /></p>\r\n            <div align="justify">Thiết kế s&acirc;n vườn kh&ocirc;ng phải l&agrave; một m&ocirc;n khoa học ch&iacute;nh x&aacute;c v&agrave; những nguy&ecirc;n tắc được sử dụng để thiết kế cũng c&oacute; nhiều c&aacute;ch n&oacute;i kh&aacute;c nhau. Ba  phạm tr&ugrave; dưới đ&acirc;y chứa những yếu tố cơ bản m&agrave; khi kết hợp ch&uacute;ng với nhau sẽ đem lại những c&aacute;ch giải th&iacute;ch thường dễ chấp nhận cho việc thiết  kế cảnh quan s&acirc;n vườn đẹp. H&atilde;y nhớ rằng thiết kế cảnh quan s&acirc;n vườn l&agrave; việc d&agrave;nh cho c&aacute; nh&acirc;n v&agrave; những nguy&ecirc;n tắc của ch&uacute;ng c&oacute; thể được ph&aacute; bỏ.   <br />\r\n            <strong>Thứ tự &ndash; C&acirc;n bằng &ndash; Sự c&acirc;n đối</strong><br />\r\n            Cấu tr&uacute;c cơ bản của s&acirc;n vườn. Thứ tự c&oacute; thể được sữ dụng qua t&iacute;nh đối xứng, như trong một s&acirc;n vườn th&ocirc;ng thường, th&ocirc;ng qua việc d&ugrave;ng c&aacute;c loại c&acirc;y hay m&agrave;u sắc&hellip;<br />\r\n            <strong>H&agrave;i ho&agrave; hay Đồng nhất</strong><br />\r\n            Khi những phần của khu vườn c&oacute; t&aacute;c động chung với nhau như to&agrave;n bộ khu vườn. Điều n&agrave;y c&oacute; thể thực hiện bằng việc sử dụng giới hạn m&agrave;u sắc, c&aacute;c loại c&acirc;y&hellip; Chủ đề của khu vườn n&ecirc;n x&acirc;y cho đồng nhất.<br />\r\n            <strong>D&ograve;ng chảy, chuyển đổi hay nhịp điệu.</strong><br />\r\n            Li&ecirc;n tục giữ &aacute;nh mắt của bạn di chuyển v&agrave; trực tiếp v&agrave;o nơi bạn muốn để nh&igrave;n thấy sự chuyển đổi dần từ độ cao v&agrave; m&agrave;u sắc để tr&aacute;nh tầm nh&igrave;n của bạn bị dừng lại đột ngột. Sự chuyện đổi cũng c&oacute; thể gi&uacute;p bạn sử dụng để tạo ra h&igrave;nh ảnh của kh&ocirc;ng gian lớn bằng việc tạo chiều s&acirc;u cho khu vườn qua việc sử dụng c&aacute;c loại c&acirc;y nhỏ v&agrave;o ph&iacute;a sau c&aacute;c c&acirc;y cao hơn.</div>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p style="text-align: center;">&nbsp;</p>', 133, 0, 0, '', NULL, NULL, '', '0', '', NULL);
INSERT INTO `tbl_product` VALUES (25, '', 'Mẫu đài phun nước', '/product_s25.jpg', NULL, '', '2010-10-21 23:39:54', '2010-10-21 23:39:54', 0, 0, NULL, '', '<div align="center">\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/dai-phun-nuoc/the-visitable-dome.jpg" /></div>\r\n</div>\r\n<div align="center">\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div align="center">\r\n<div align="center">\r\n<div align="center">\r\n<div align="center">\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/dai-phun-nuoc/001.jpg" />&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n<div align="center">\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/dai-phun-nuoc/img_2130.jpg" /></div>\r\n</div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/dai-phun-nuoc/blue_fountain.jpg" /></div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/dai-phun-nuoc/dai%20nuoc%20da%20nang2.jpg" /></div>\r\n<div>\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div align="center">\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/dai-phun-nuoc/daiphunnghethuat.jpg" /></div>\r\n</div>\r\n<div align="center">\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div align="center">\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/dai-phun-nuoc/the-fountain-of-illusion.jpg" /></div>\r\n</div>\r\n<div align="center">\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div align="center">\r\n<div align="center">\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/dai-phun-nuoc/the-rainbow-fountain.jpg" /></div>\r\n</div>\r\n</div>\r\n<div align="center">\r\n<div style="text-align: center;">&nbsp;</div>\r\n</div>\r\n<div style="text-align: center;"><img alt="" src="http://sonthuy.vn/images/stories/dai-phun-nuoc/wadakura_fountain_park4_600x.jpg" /></div>', 134, 0, 0, '', NULL, NULL, '', '0', '', NULL);
INSERT INTO `tbl_product` VALUES (26, '', 'ĐÀI PHUN NƯỚC NGHỆ THUẬT', '/product_s26.jpg', NULL, '', '2010-10-21 23:40:43', '2010-10-21 23:40:43', 0, 0, NULL, '', '<table class="contentpaneopen">\r\n    <tbody>\r\n        <tr>\r\n            <td valign="top">\r\n            <div style="text-align: left;"><img width="150" height="100" src="http://sonthuy.vn/images/stories/dpn06.jpg" title="" alt="" /></div>\r\n            <div>&nbsp;</div>\r\n            <div>h&igrave;nh ảnh minh họa!!!!!!!! cty chuy&ecirc;n cung c&acirc;p lăp đăt h&ecirc; thống ,thi&ecirc;t bị về đ&agrave;i phun nươc ,hồ bơi ,hệ th&ocirc;ng\r\n            <div><img width="321" height="400" src="http://sonthuy.vn/images/stories/dpn06.jpg" title="" alt="" />&nbsp;</div>\r\n            </div>\r\n            <div><img width="383" height="400" src="http://sonthuy.vn/images/stories/dpn08.jpg" title="" alt="" />&nbsp;</div>\r\n            <div>&nbsp;</div>\r\n            <div>ch&uacute;ng t&ocirc;i xin h&acirc;n hạnh gửi đến c&aacute;c bạn&nbsp;những h&igrave;nh&nbsp;ảnh m&agrave; đep đ&atilde; trải nghiệm v&agrave; &nbsp;th&agrave;nh c&ocirc;ng trong lĩnh vực thiết kế, thi c&ocirc;ng c&aacute;c c&ocirc;ng tr&igrave;nh phun nước nghệ thuật, hệ thống tưới phun v&agrave; c&aacute;c c&ocirc;ng tr&igrave;nh c&ocirc;ng c&ocirc;ng, c&ocirc;ng vi&ecirc;n, kh&aacute;ch sạn, Trụ sở c&aacute;c cơ quan, Văn ph&ograve;ng. Với nhiều chủng loại sản phẩm đặc sắc v&agrave; độc đ&aacute;o, ch&uacute;ng t&ocirc;i hy vọng sẽ mang lại những gi&acirc;y ph&uacute;t thư gi&atilde;n sau những giờ l&agrave;m việc căng thẳng. &hellip; ch&uacute;ng t&ocirc;i đảm bảo chất lượng&nbsp;ch&iacute;nh h&atilde;ng&nbsp;v&agrave; gi&aacute; cả cực kỳ ưu đ&atilde;</div>\r\n            </td>\r\n        </tr>\r\n    </tbody>\r\n</table>', 134, 0, 0, '', NULL, NULL, '', '0', '', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_product_category`
-- 

CREATE TABLE `tbl_product_category` (
  `categories_id` int(11) NOT NULL auto_increment,
  `categories_name` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `categories_image` varchar(64) character set utf8 collate utf8_unicode_ci default NULL,
  `parent` int(11) default '0',
  `sort` int(3) default '0',
  `indexpage` tinyint(4) default '0',
  `status` tinyint(3) default '0',
  `date_added` datetime default '0000-00-00 00:00:00',
  `last_modified` datetime default NULL,
  `categories_description` text character set utf8 collate utf8_turkish_ci,
  `lang` varchar(4) character set utf8 collate utf8_unicode_ci default NULL,
  `type` int(11) NOT NULL default '1',
  `code` varchar(50) character set utf8 collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`categories_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=136 ;

-- 
-- Dumping data for table `tbl_product_category`
-- 

INSERT INTO `tbl_product_category` VALUES (131, 'Hòn Non Bộ', NULL, 0, 0, 0, 0, '2010-10-21 22:54:43', '2010-10-21 22:54:43', NULL, '', 0, 'honnonbo');
INSERT INTO `tbl_product_category` VALUES (130, 'Đá Nghệ Thuật', NULL, 0, 0, 0, 0, '2010-10-21 22:54:24', '2010-10-21 22:54:24', NULL, '', 0, 'danghethuat');
INSERT INTO `tbl_product_category` VALUES (132, 'Tiểu Cảnh', NULL, 0, 0, 0, 0, '2010-10-21 22:54:53', '2010-10-21 22:54:53', NULL, '', 0, 'tieucanh');
INSERT INTO `tbl_product_category` VALUES (133, 'Thiết Kế Cảnh Quan', NULL, 0, 0, 0, 0, '2010-10-21 22:55:15', '2010-10-21 22:55:15', NULL, '', 0, 'thietkecanhquan');
INSERT INTO `tbl_product_category` VALUES (135, 'asdasdasd', NULL, 0, 1, 0, 0, '2010-10-22 11:12:18', '2010-10-22 11:12:18', NULL, 'vn', 0, 'asdasd');

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_providers`
-- 

CREATE TABLE `tbl_providers` (
  `providers_id` int(11) NOT NULL auto_increment,
  `providers_name` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `providers_address` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `providers_phone` varchar(100) character set utf8 collate utf8_unicode_ci default NULL,
  `providers_email` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  `providers_status` tinyint(3) default '0',
  `providers_dateadded` datetime NOT NULL default '0000-00-00 00:00:00',
  `lang` varchar(4) character set utf8 collate utf8_unicode_ci default NULL,
  `providers_image` varchar(255) character set utf8 collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`providers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `tbl_providers`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_user`
-- 

CREATE TABLE `tbl_user` (
  `Id` int(11) NOT NULL auto_increment,
  `uid` varchar(20) NOT NULL,
  `pwd` varchar(32) NOT NULL,
  `tbl_user_date_added` int(11) default NULL,
  `last_modified` int(11) NOT NULL,
  `tbl_user_status` int(2) NOT NULL,
  `status` int(11) default NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `tbl_user`
-- 

INSERT INTO `tbl_user` VALUES (1, 'buitandat1987', '93fde84fcc78f90f6281946a9f565838', NULL, 0, 0, NULL);
INSERT INTO `tbl_user` VALUES (2, 'chausa289', 'ali33vn', NULL, 0, 0, NULL);
INSERT INTO `tbl_user` VALUES (3, 'tandat', '7f9a3c70557fbd3fef36', 0, 0, 0, 0);
INSERT INTO `tbl_user` VALUES (4, 'tan_dat', '7f9a3c70557fbd3fef36', 0, 0, 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `tbl_visitor`
-- 

CREATE TABLE `tbl_visitor` (
  `session_id` varchar(255) NOT NULL default '',
  `activity` int(11) NOT NULL,
  `member` enum('y','n') default 'n',
  `ip_address` varchar(255) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `user_agent` varchar(255) default NULL,
  PRIMARY KEY  (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `tbl_visitor`
-- 

INSERT INTO `tbl_visitor` VALUES ('59a53bb22b8268d950f5dc2b05bab1f4', 1283476182, 'n', '123.21.184.191', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2)');
INSERT INTO `tbl_visitor` VALUES ('20863980925172ebf5a8df7fc3d45922', 1283476568, 'n', '222.253.158.54', '', 'Mozilla/5.0 (Windows NT 6.1; rv:2.0b4) Gecko/20100818 Firefox/4.0b4');
INSERT INTO `tbl_visitor` VALUES ('b248e8c03b44ad5e66c4d8d445236bf0', 1283475986, 'n', '123.21.184.191', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2)');
INSERT INTO `tbl_visitor` VALUES ('ff3a4877f74ae2fe2406837639855757', 1283443106, 'n', '123.21.184.191', '', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_1_3 like Mac OS X; en) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7E18 Safari/528.16');
INSERT INTO `tbl_visitor` VALUES ('632b98eaa113ddab722cfb1cec32979e', 1283440364, 'n', '118.69.69.227', '', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; GTB6.6)');
INSERT INTO `tbl_visitor` VALUES ('439df4b1bea67c6dc3f35fb437ed7312', 1283399529, 'n', '113.169.85.68', '', 'Mozilla/5.0 (Windows NT 6.1; rv:2.0b4) Gecko/20100818 Firefox/4.0b4');
INSERT INTO `tbl_visitor` VALUES ('e535ce94a86ee639315a2c2495830e34', 1283364683, 'n', '116.111.161.83', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022; AskTbFXTV5/5.8.0.12304)');
INSERT INTO `tbl_visitor` VALUES ('7db21b91d686414ca38aceb9eb5190a7', 1283352194, 'n', '112.161.14.90', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB6.5; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)');
INSERT INTO `tbl_visitor` VALUES ('762ccf6465b53dea1117ef1fe19d8b06', 1283351866, 'n', '115.75.98.17', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('39dfb1f93805404dbe8e15671bd9541a', 1283340003, 'n', '206.183.1.74', '', 'Mozilla/4.0 (compatible; http://search.thunderstone.com/texis/websearch/about.html)');
INSERT INTO `tbl_visitor` VALUES ('efdb5811b98e5e14a21b52c59cd70c36', 1283336108, 'n', '123.21.184.191', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2)');
INSERT INTO `tbl_visitor` VALUES ('2fda5647440fa23b44732e9ab4e55a17', 1283334081, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('722f7651d64061518f2b8b127ea4e504', 1283334439, 'n', '123.21.184.191', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.127 Safari/533.4');
INSERT INTO `tbl_visitor` VALUES ('f5149d8753fd549342c1ce635b013421', 1283334076, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('d9c2d72489e58f154e7ad58f88da9293', 1283334079, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('6091d88eec892d718d07c7df650882f5', 1283334073, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('b302815ce1d9763ce3b3477ae759c273', 1283334070, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f35eab6ea66a937dda50f8a139be948f', 1283334066, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('87be734143c7bedd1312856d87c0e3f3', 1283334063, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('802517314595003dd42881a603f46fa6', 1283334060, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('59181dda08a65394655609e248c8c19d', 1283334057, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('08656a55b89fafe887bb0a299cee566a', 1283334051, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('ea82f567fa77b086ad556e5f8907f7ac', 1283334054, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('7ea0ba50b7a9fc3f4b16441609ced898', 1283334048, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('88132fa7aeb0dda2694dc62acb1576e6', 1283334045, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('dbe5401fa1f63ba1cbcafc7517fd739a', 1283334039, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('547135e4c0df3d73dc858c123521a227', 1283334042, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('9ca1cb6b8cf2337bb5d169fb5445abd7', 1283334036, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f06b7c8422ad560ae3cd0c9eb523b4c4', 1283334033, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('77824af1b5f3b9504373f3329ab49f4c', 1283334031, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('ae2cfa9a0e1b71c8e7a26631b1f84514', 1283334024, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('6bb7048fc4b6cbd2b4dc6d8e66e7921f', 1283334027, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('332968b47ca35097e2d34b3b1dbaa05b', 1283334021, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('cf103249db24e1db99d4dc55e0fd5d33', 1283334018, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('e82b0e3f3b438a8d4e682a0c519ff5e2', 1283334016, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('2cf2bb01c050d6babd1dbdd437dd390a', 1283334010, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('657c604f979a3f10b9e680d5676a52a9', 1283334013, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('9447cab984fd08ef9259bf0905c9c57d', 1283334004, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('d518f1f4d04c6674eb40ed76809b407b', 1283334007, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f0cb0ce1c8d0d58c28f55a6b39615449', 1283334001, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('3900a0fff8a880ce59d3b884d61537da', 1283333998, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('d95f53738edb7ae6256573c056cea76b', 1283333992, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('749e0dbe8859b0abbf43a1ff584c5ae2', 1283333995, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('81676ef84dde47946d6ed73455b1a011', 1283333986, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('dd587571975db4cdd0b1776d9bb53033', 1283333989, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('9cb023c805da33f85b1696a66e29d0ea', 1283333982, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('6d3fe0bd72ea2a119b85fa4f50ac17f8', 1283333979, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('5d59a182be31cacef3ba3014abd15312', 1283333976, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('cca8add4333c6fea0ce65b28689d2532', 1283333973, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('bc714d0e7e2ff1c81f764fb505befe30', 1283333970, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('fe7620b107cf978e3ba163f5644b6504', 1283333965, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('e63c067ffb471745e5e62938e4d62c1a', 1283333959, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('458b3361f2293cf461722d85ab3ddbb8', 1283333962, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('8629cd44e973a03235edd342a49dea59', 1283333954, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('8f0188f72658511cfef103394cc5d863', 1283333957, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('382cf1e193d5bd6021a96f9b4dc5cf74', 1283333944, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('eb8a4f589a5dcdd9900fb6d0e9646ce1', 1283333947, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f681e894f38b6084c8ff8d630479b600', 1283333936, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('0abb1764afb2f14643f030842b8feedd', 1283333941, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('bd836b354d8599e50bd5308d2190f9af', 1283333933, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('e21457bef56c9993965f0668a2730113', 1283333927, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('6451052edf0cbd3b9007f25192f02aea', 1283333930, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('4cacba5c6b5a0c7ce8b25e7b660e630b', 1283333922, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('8c4f75fed5d66e1e67becec3f3f7dd06', 1283333924, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('a122dc9e21a3053cced80c7193e4523c', 1283333916, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('142347216e2ba2149dea16724613fb1c', 1283333919, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f98128c763b656ec6272f80da04d2e9a', 1283333913, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('c9e5e26f2c6d8a9d869550fca9b7c5d2', 1283333909, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('e82bcb20d4a3838396b22b1db010f00a', 1283333907, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('b2bbbeef64a36e27865293f1d1dc26c0', 1283333905, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('19fce023b2eeb1ebdfb97613242586af', 1283333900, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('8cb385cfbc22d7b02ef39fb167d551e1', 1283333897, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('036340e63d4dc25906460b0a2f2180f5', 1283333895, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('eba1a6198d374ccf1d36a897e801557c', 1283333892, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('e576af19c63963a2f8e0609ad69e4b88', 1283333889, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('299a8ab1519e60812c36a66a63ff13f8', 1283333883, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('9d97f5d6143f127ab0d6e2f0717d621d', 1283333886, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f9f53622cd7bec60e65c6bd9f5e27644', 1283333880, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('6b5e289b2734578af3d02fe98f41588a', 1283333877, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('a467c1906ed13e2c39d47dd95e1ff19e', 1283333873, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('a0bb6e4a060f20b31be2c306f1cce103', 1283333869, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f5d17a8712e1bdb0041badf07b8b933b', 1283333863, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('830e77379e064db80c62d3bdc1ee26d6', 1283333867, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('9df66f4cc2aea1762b63e3c5d313a1ac', 1283333861, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('678671db79f7139f10ed241d237a850c', 1283333858, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('d168bf092ae2c838a382fae77ae053d7', 1283333853, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('bd35f006fafdcaaa2247c29b56d34245', 1283333855, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('9ca6ceb347c2b87deb59c7ddb941841a', 1283333847, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('b7d69e22acbcc0af8f7cf44e6674cf04', 1283333850, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('8919650e5b83da91f40ebdf43ffecc95', 1283333841, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('b21b25eb5aaa1f4a126633266c968692', 1283333844, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('da878413492bce8d14e84eb040e25c1e', 1283333838, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('cdd1a80674f956656f73f98be4bd7b96', 1283333835, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('6777ff9d94d51731dea85d23b60212ef', 1283333829, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('2f4fbfcf41b7f351a5efc22077a6c180', 1283333832, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('81f972bbe43b5099dab366f2fa6ddb30', 1283333825, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('49a54e45e4664d19e28af61ea93781e9', 1283333822, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('1490cdeff4ddc66ce8d333c7ae8aca09', 1283333819, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('de40b23e97cecb0cc72a3c7d348630cb', 1283333813, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('4070c7d1788662525f77ed712fe00838', 1283333816, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('89cc58551fe820760242256686d882b5', 1283333811, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('9bea2e265f0c4b427cb3ca6aece83386', 1283333805, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('7448bbf647304c4e12246d2baf0f5dc6', 1283333808, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('4960cacf42a28163ac2f79e68d498710', 1283333802, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('dd22a09a0c636923b4c7b0405fb8701c', 1283333796, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('8ac53010b7702f62358e2fe0fefea627', 1283333791, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('644eb997a0bdbec77fe38325d5841104', 1283333788, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('491c5f2bd3e68da07b93fe5c828ada95', 1283333781, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('219ff1c3a172e21fb8b56e9968542aea', 1283333785, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('e1acee66b24997d6843f0efdfafa6325', 1283333778, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('6511e659d59f4dc3241e4e832534cec1', 1283333775, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('8653e5e54eb30686962b0d4fa498c078', 1283333770, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('21a6962a3f54632571cc39f2866342dc', 1283333773, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('001e5892cc72c79833a9e140b98a681d', 1283333767, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('8511380ee651031ea20b170aa57dfd90', 1283333764, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('39323920a07b3a004d2a1dca750aa3e3', 1283333759, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('1e1d9a7e7a1d1c109829a1f855fd2304', 1283333755, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('4595c4d4be1c779e2f9117958f2c8998', 1283333752, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('ce4c755dedef3726b92a4d60a46a73bb', 1283333750, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('a6d889085fe4afc55264ce573ef6dad1', 1283333746, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('691c406740218843387f8308ad85a201', 1283333743, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('c9822c76327ba38f63089ec4f19a75e2', 1283333740, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('94b6c24cbbbde24d0168afb178b871fb', 1283333736, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('079f653ba6d244dd14bb02e7b78751cd', 1283333729, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f393f23a4d0ae23de12f5fa7257fa5f7', 1283333732, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('ce66d6a8194fbc83153642c7bba1bb26', 1283333726, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('918f2842a74bdfe8dcd4cb71c7c942c4', 1283333723, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('ba79bc62ad88788c8a9872b0bac5a604', 1283333717, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('059f30bfe946452e2e90ef6904691598', 1283333720, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('090a87c48900e3f5868db32485dd6f7c', 1283333714, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('cdf2d345489fd3a0125b548799753cb0', 1283333708, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('ef809a6fef48e614e06a3b407ac8b2a4', 1283333711, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('b5ebb4a424f653c11f4f1405fdb84338', 1283333705, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('da465780c19e534547e3e5c722fda00a', 1283333701, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('c58e06df55e216aacd91ad5b88be92a1', 1283333693, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('1e19bae5ecf8fba08f054f6843ba4e89', 1283333697, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f984045689bc32baf42d015db67fd4d2', 1283333690, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('32ad301fd0999792daa42f58e34f0690', 1283333684, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('a019a2a143b9feda9090bac52aeebc46', 1283333687, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('69904f17dc9a0e9be169669b111ecfc2', 1283333679, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('19d211797e428c3f7ea49ba352e85f28', 1283333681, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('9f0c56d60d82c0576fc7f2fc298c9f29', 1283333675, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('3a31563128626f75ecb34f94c51b1005', 1283333671, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('7f6372c9faeba72078b46875d1e47a5c', 1283333669, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('d8d72ed35e8b368184b958c68052b94c', 1283333662, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('71c01ed6caf99c7c4f55388eefafdd1b', 1283333665, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('4ad74382352e79f44a791555bcbafb73', 1283333655, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('c11eb4a7322f9365dde6d1eb4c124ba6', 1283333647, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('7221300dbde2654211caa832e3734eb7', 1283333644, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('ee8138d5ce402193249badb7c65cd634', 1283333636, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('371159f94246cec53a09232825cb214f', 1283333640, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('90291e1148f7b9957f678e65b054930c', 1283333631, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('f934d9a4e9f4e7a38c6f287c0137ec20', 1283333626, 'n', '65.55.3.141', '', 'msnbot/2.0b (+http://search.msn.com/msnbot.htm)._');
INSERT INTO `tbl_visitor` VALUES ('729f175250a1a76615d0bbdf342bc8b2', 1283333303, 'n', '123.21.184.191', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB0.0; InfoPath.2; .NET CLR 2.0.50727)');
INSERT INTO `tbl_visitor` VALUES ('d270ec13bd05ad25bd41fa6620393661', 1283333236, 'n', '123.21.184.191', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.127 Safari/533.4');
INSERT INTO `tbl_visitor` VALUES ('5b12eeadbede6fdd0ddef82428e8132d', 1283327667, 'n', '115.75.93.241', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('449e1cb9ec543360082a5a1a4e59a9d2', 1283327418, 'n', '115.75.93.241', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2) Gecko/20100115 Firefox/3.6');
INSERT INTO `tbl_visitor` VALUES ('bba8f12d1c1b35240875298d6c89e012', 1283326112, 'n', '123.21.184.191', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; GTB0.0; InfoPath.2; .NET CLR 2.0.50727)');
INSERT INTO `tbl_visitor` VALUES ('eef284215bd5fba509610d44513ec6d0', 1283331472, 'n', '123.21.184.191', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('abdaac176ee8959f6a6131db9b50c84c', 1283332969, 'n', '123.20.228.185', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2)');
INSERT INTO `tbl_visitor` VALUES ('6eded9ff2d0f704843936d9972ae60a2', 1283313665, 'n', '123.20.228.185', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; GTB6.5; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2)');
INSERT INTO `tbl_visitor` VALUES ('e73aae1dbc2cb5c73555c2a77107bc1d', 1283313260, 'n', '123.20.228.185', '', 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.127 Safari/533.4');
INSERT INTO `tbl_visitor` VALUES ('916ca5a4664fab5b44987d0d81ad6980', 1283313024, 'n', '24.84.204.118', '', 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3');
INSERT INTO `tbl_visitor` VALUES ('ea9ace28e47b9f43d3b1d6c7a52d36dd', 1283334060, 'n', '123.20.228.185', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('bf784e3cacb00123d502298a4a8586f1', 1283309629, 'n', '115.75.71.102', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2) Gecko/20100115 Firefox/3.6');
INSERT INTO `tbl_visitor` VALUES ('9bc834e6993e621244eb3d49d08a87b5', 1283313530, 'n', '123.20.228.185', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('dd2219e5afeb17cf79d004c773f18ca0', 1283306699, 'n', '72.94.249.38', '', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)');
INSERT INTO `tbl_visitor` VALUES ('f0c26356315b05a059720376ad7c3a8c', 1283314743, 'n', '123.20.228.185', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2)');
INSERT INTO `tbl_visitor` VALUES ('a4b05685e6269479ccbb80010f8cbfab', 1283332466, 'n', '123.20.228.185', 'http://cameradocdao.com/act/category/90/2/H%C3%A0ng%20%C4%91%E1%BB%99c.htm', 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('0287147dc0ef350fc1302c94cee640e4', 1283322770, 'n', '123.20.228.185', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('85a1741f539bd047d769e73f074891a4', 1283305029, 'n', '123.20.228.185', '', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2)');
INSERT INTO `tbl_visitor` VALUES ('5b6e23aaa428e32399b9926e888ffd3b', 1283352393, 'n', '115.75.135.119', 'http://cameradocdao.com/act/category/38/Camera_ng%E1%BB%A5y_trang.htm', 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('0db69f08e7442bef292dca0307b4c8e3', 1283705438, 'n', '127.0.0.1', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('c03550d3518956c65acb8988956b7bdf', 1283706770, 'n', '127.0.0.1', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('fd2fc3813577eebe7aad285c137ab27f', 1283734524, 'n', '127.0.0.1', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('6489d4f3a2e66cc79bf6a2eed1d61c48', 1283877200, 'n', '127.0.0.1', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('842f711f3b69cc0659d7bc2fadb0a319', 1283877191, 'n', '127.0.0.1', '', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)');
INSERT INTO `tbl_visitor` VALUES ('5129b4eb8e2973742d35510eb83df64d', 1284177277, 'n', '127.0.0.1', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8');
INSERT INTO `tbl_visitor` VALUES ('f0377b0f84fbe9913c4beb053329e08d', 1284049445, 'n', '127.0.0.1', '', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)');
INSERT INTO `tbl_visitor` VALUES ('6131a06e8b8a9443a34627f69490231d', 1284225263, 'n', '127.0.0.1', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.9) Gecko/20100824 Firefox/3.6.9');
INSERT INTO `tbl_visitor` VALUES ('92d07ef5202061485fc23635ef38289e', 1284373285, 'n', '127.0.0.1', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.9) Gecko/20100824 Firefox/3.6.9');
INSERT INTO `tbl_visitor` VALUES ('30a91513feb23bcfaf5809b483c8d3c9', 1284424626, 'n', '127.0.0.1', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi; rv:1.9.2.9) Gecko/20100824 Firefox/3.6.9');

-- --------------------------------------------------------

-- 
-- Table structure for table `visitors`
-- 

CREATE TABLE `visitors` (
  `session_id` varchar(255) NOT NULL default '',
  `activity` datetime NOT NULL default '0000-00-00 00:00:00',
  `member` enum('y','n') default 'n',
  `ip_address` varchar(255) NOT NULL default '',
  `refurl` varchar(255) NOT NULL default '',
  `user_agent` varchar(255) default NULL,
  PRIMARY KEY  (`session_id`),
  KEY `session_id` (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `visitors`
-- 

