-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Jeu 17 Novembre 2011 à 23:41
-- Version du serveur: 5.0.51
-- Version de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de données: `ford`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `tbl_company`
-- 

CREATE TABLE `tbl_company` (
  `idcompany` int(11) NOT NULL auto_increment,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `nguoidaidien` varchar(200) collate utf8_unicode_ci NOT NULL,
  `phone` varchar(200) collate utf8_unicode_ci NOT NULL,
  `diachi` varchar(200) collate utf8_unicode_ci NOT NULL,
  `logo` varchar(200) collate utf8_unicode_ci NOT NULL,
  `text` text collate utf8_unicode_ci NOT NULL,
  `mota` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`idcompany`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Contenu de la table `tbl_company`
-- 

INSERT INTO `tbl_company` VALUES (1, 'Công ty cổ phần Bến Thành ÔTô', 'Nguyễn Quang Châu', ' 0903.681.090', '831 Truong Chinh street, Tay Thanh ward, Tan Phu district, Ho Chi Minh city', 'logo.png', ' Trực tiếp thiết kế và quản trị theo ý tưởng của Nguyễn Quang Châu<br/>\r\nHotline: 0903.681.090- 093.757.1090<br/>\r\nwebsite: benthanhford.vn- fordbenhthanh.com-fordbenhthanh.com.vn', '  BẾN THÀNH fORD CHÀO MỪNG ANH CHỊ ĐẾN VỚI SHOWROOM TRỰC TUYẾN-MỚI ANH CHỊ THAM QUAN, CHỌN XE VÀ LIÊN HỆ ĐỂ ĐƯỢC TƯ VẤN\r\n');
